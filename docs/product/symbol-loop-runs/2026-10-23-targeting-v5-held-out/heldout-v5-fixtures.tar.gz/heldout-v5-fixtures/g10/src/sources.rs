use crate::record::{parse_line, Record};

/// Records from a single file's contents. Lines that do not parse (stack
/// traces, blank lines) are skipped.
pub struct LineSource {
    lines: std::vec::IntoIter<String>,
    pub skipped: usize,
}

impl LineSource {
    pub fn new(text: &str) -> LineSource {
        let lines: Vec<String> = text.lines().map(str::to_string).collect();
        LineSource { lines: lines.into_iter(), skipped: 0 }
    }
}

impl Iterator for LineSource {
    type Item = Record;

    fn next(&mut self) -> Option<Record> {
        for line in self.lines.by_ref() {
            match parse_line(&line) {
                Some(r) => return Some(r),
                None => self.skipped += 1,
            }
        }
        None
    }
}

/// Records from a rotated set (`app.log.3`, `app.log.2`, `app.log.1`,
/// `app.log`), read oldest segment first.
pub struct RotatedSource {
    segments: Vec<String>,
    next_segment: usize,
    current: Option<LineSource>,
}

impl RotatedSource {
    /// `segments` must already be ordered oldest first.
    pub fn new(segments: Vec<String>) -> RotatedSource {
        RotatedSource { segments, next_segment: 0, current: None }
    }
}

impl Iterator for RotatedSource {
    type Item = Record;

    fn next(&mut self) -> Option<Record> {
        loop {
            if let Some(cur) = self.current.as_mut() {
                if let Some(r) = cur.next() {
                    return Some(r);
                }
                self.current = None;
            }
            let seg = self.segments.get(self.next_segment)?;
            self.next_segment += 1;
            if seg.trim().is_empty() {
                return None;
            }
            self.current = Some(LineSource::new(seg));
        }
    }
}

/// Rotation number of a file name: `app.log` is 0, `app.log.2` is 2.
/// Compressed segments (`.gz`) are not supported and yield `None`.
fn rotation_index(name: &str) -> Option<u32> {
    if name.ends_with(".gz") {
        return None;
    }
    match name.rsplit_once('.') {
        Some((_, suffix)) if suffix.chars().all(|c| c.is_ascii_digit()) && !suffix.is_empty() => suffix.parse().ok(),
        _ => Some(0),
    }
}

/// Opens a set of log files given as `(file name, contents)`. A single file
/// is read directly; several files are treated as one rotated set.
pub fn open(files: &[(&str, &str)]) -> Box<dyn Iterator<Item = Record>> {
    let mut usable: Vec<(u32, &str)> =
        files.iter().filter_map(|(name, text)| rotation_index(name).map(|i| (i, *text))).collect();
    match usable.len() {
        0 => Box::new(std::iter::empty()),
        1 => Box::new(LineSource::new(usable[0].1)),
        _ => {
            // highest rotation number is the oldest
            usable.sort_by(|a, b| b.0.cmp(&a.0));
            Box::new(RotatedSource::new(usable.into_iter().map(|(_, t)| t.to_string()).collect()))
        }
    }
}
