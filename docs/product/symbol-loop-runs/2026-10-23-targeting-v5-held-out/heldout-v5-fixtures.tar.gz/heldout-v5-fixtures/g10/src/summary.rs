use std::collections::BTreeMap;

use crate::record::{Level, Record};

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Summary {
    pub total: usize,
    pub by_level: BTreeMap<Level, usize>,
    pub by_component: BTreeMap<String, usize>,
    pub first_ts: Option<u64>,
    pub last_ts: Option<u64>,
    pub errors: Vec<String>,
    pub out_of_order: usize,
}

impl Summary {
    pub fn from_records<I: IntoIterator<Item = Record>>(records: I) -> Summary {
        let mut s = Summary::default();
        for r in records {
            s.total += 1;
            *s.by_level.entry(r.level).or_insert(0) += 1;
            *s.by_component.entry(r.component.clone()).or_insert(0) += 1;
            if let Some(last) = s.last_ts {
                if r.ts < last {
                    s.out_of_order += 1;
                }
            }
            s.first_ts = Some(s.first_ts.map_or(r.ts, |f| f.min(r.ts)));
            s.last_ts = Some(s.last_ts.map_or(r.ts, |l| l.max(r.ts)));
            if r.level == Level::Error {
                s.errors.push(format!("{} {}: {}", r.ts, r.component, r.message));
            }
        }
        s
    }

    pub fn count(&self, level: Level) -> usize {
        self.by_level.get(&level).copied().unwrap_or(0)
    }

    pub fn span_secs(&self) -> u64 {
        match (self.first_ts, self.last_ts) {
            (Some(a), Some(b)) => b - a,
            _ => 0,
        }
    }

    pub fn render(&self) -> String {
        let mut out = format!("{} records over {}s\n", self.total, self.span_secs());
        for (level, n) in &self.by_level {
            out.push_str(&format!("{:<5} {}\n", level, n));
        }
        out
    }
}
