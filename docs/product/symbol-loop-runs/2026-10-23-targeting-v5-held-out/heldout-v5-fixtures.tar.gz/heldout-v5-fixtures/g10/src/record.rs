use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Level {
    Debug,
    Info,
    Warn,
    Error,
}

impl Level {
    pub fn parse(s: &str) -> Option<Level> {
        match s {
            "DEBUG" | "TRACE" => Some(Level::Debug),
            "INFO" => Some(Level::Info),
            "WARN" | "WARNING" => Some(Level::Warn),
            "ERROR" | "FATAL" => Some(Level::Error),
            _ => None,
        }
    }
}

impl fmt::Display for Level {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Level::Debug => "DEBUG",
            Level::Info => "INFO",
            Level::Warn => "WARN",
            Level::Error => "ERROR",
        };
        f.pad(s)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Record {
    pub ts: u64,
    pub level: Level,
    pub component: String,
    pub message: String,
}

/// Parses `<unix-ts> <LEVEL> <component>: <message>`.
pub fn parse_line(line: &str) -> Option<Record> {
    let line = line.trim_end_matches(['\r', '\n']);
    let mut parts = line.splitn(3, ' ');
    let ts = parts.next()?.parse().ok()?;
    let level = Level::parse(parts.next()?)?;
    let rest = parts.next()?;
    let (component, message) = rest.split_once(": ")?;
    if component.is_empty() || component.contains(' ') {
        return None;
    }
    Some(Record { ts, level, component: component.to_string(), message: message.to_string() })
}
