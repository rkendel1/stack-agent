//! Read application logs, including logrotate-style rotated sets, and
//! summarise them.

pub mod record;
pub mod sources;
pub mod summary;

pub use record::{parse_line, Level, Record};
pub use sources::{open, LineSource, RotatedSource};
pub use summary::Summary;
