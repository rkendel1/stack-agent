use logsieve::{open, parse_line, Level, Summary};

const OLDEST: &str = "\
1000 INFO api: started
1005 WARN db: slow query 812ms
1010 ERROR api: upstream timeout
";
const CURRENT: &str = "\
1100 INFO api: request served
1101 DEBUG cache: hit ratio 0.93
    at frame 1
1102 ERROR db: connection reset
";

#[test]
fn parses_a_line() {
    let r = parse_line("1700000000 WARN worker-3: queue depth 120").unwrap();
    assert_eq!(r.ts, 1700000000);
    assert_eq!(r.level, Level::Warn);
    assert_eq!(r.component, "worker-3");
    assert!(parse_line("not a log line").is_none());
}

#[test]
fn single_file_summary() {
    let s = Summary::from_records(open(&[("app.log", CURRENT)]));
    assert_eq!(s.total, 3);
    assert_eq!(s.count(Level::Error), 1);
    assert_eq!(s.render(), "3 records over 2s\nDEBUG 1\nINFO  1\nERROR 1\n");
}

#[test]
fn rotated_set_is_read_oldest_first() {
    let files = [("app.log", CURRENT), ("app.log.1", OLDEST)];
    let s = Summary::from_records(open(&files));
    assert_eq!(s.total, 6);
    assert_eq!(s.out_of_order, 0);
    assert_eq!(s.span_secs(), 102);
}

#[test]
fn empty_rotated_segment_is_skipped() {
    let files = [("app.log", CURRENT), ("app.log.1", ""), ("app.log.2", OLDEST)];
    let s = Summary::from_records(open(&files));
    assert_eq!(s.total, 6);
    assert_eq!(s.errors, vec!["1010 api: upstream timeout", "1102 db: connection reset"]);
}

#[test]
fn compressed_segments_are_ignored() {
    let files = [("app.log", CURRENT), ("app.log.3.gz", "binary")];
    let mut n = 0;
    for r in open(&files) {
        assert!(r.ts >= 1100);
        n += 1;
    }
    assert_eq!(n, 3);
}

#[test]
fn per_component_counts_across_rotation() {
    let files = [("svc.log.2", OLDEST), ("svc.log.1", "\n\n"), ("svc.log", CURRENT)];
    let mut components = Vec::new();
    for r in open(&files) {
        components.push(r.component);
    }
    assert_eq!(components, vec!["api", "db", "api", "api", "cache", "db"]);
}
