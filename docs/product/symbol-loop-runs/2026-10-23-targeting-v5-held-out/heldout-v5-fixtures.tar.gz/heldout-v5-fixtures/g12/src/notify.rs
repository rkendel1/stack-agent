use crate::order::Order;
use crate::status::OrderStatus;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Email {
    pub order_id: u64,
    pub subject: String,
}

/// Remembers the last status seen per order and emits an email on the
/// transitions customers care about.
#[derive(Debug, Default)]
pub struct Notifier {
    seen: Vec<(u64, OrderStatus)>,
    pub outbox: Vec<Email>,
}

fn subject_for(old: Option<OrderStatus>, new: OrderStatus) -> Option<&'static str> {
    match (old, new) {
        (Some(o), n) if o == n => None,
        (_, OrderStatus::ReadyToShip) => Some("Thanks for your payment"),
        (_, OrderStatus::Shipped) => Some("Your order has shipped"),
        (_, OrderStatus::Delivered) => Some("Your order was delivered"),
        (Some(_), OrderStatus::Cancelled) => Some("Your order was cancelled"),
        _ => None,
    }
}

impl Notifier {
    pub fn new() -> Self {
        Notifier::default()
    }

    pub fn observe(&mut self, order: &Order) {
        let new = order.status();
        let old = self.seen.iter().find(|(id, _)| *id == order.id).map(|(_, s)| *s);
        if let Some(subject) = subject_for(old, new) {
            self.outbox.push(Email { order_id: order.id, subject: subject.to_string() });
        }
        match self.seen.iter_mut().find(|(id, _)| *id == order.id) {
            Some(slot) => slot.1 = new,
            None => self.seen.push((order.id, new)),
        }
    }
}
