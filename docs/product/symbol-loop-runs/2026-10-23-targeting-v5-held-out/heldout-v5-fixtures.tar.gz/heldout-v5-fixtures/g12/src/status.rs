use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OrderStatus {
    AwaitingPayment,
    ReadyToShip,
    Shipped,
    Delivered,
    Cancelled,
}

impl OrderStatus {
    /// Final states accept no further changes.
    pub fn is_final(&self) -> bool {
        matches!(self, OrderStatus::Delivered | OrderStatus::Cancelled)
    }

    pub fn customer_message(&self) -> &'static str {
        match self {
            OrderStatus::AwaitingPayment => "We are waiting for your payment.",
            OrderStatus::ReadyToShip => "Your order is being packed.",
            OrderStatus::Shipped => "Your order is on its way.",
            OrderStatus::Delivered => "Your order has been delivered.",
            OrderStatus::Cancelled => "Your order was cancelled.",
        }
    }
}

impl fmt::Display for OrderStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            OrderStatus::AwaitingPayment => "awaiting_payment",
            OrderStatus::ReadyToShip => "ready_to_ship",
            OrderStatus::Shipped => "shipped",
            OrderStatus::Delivered => "delivered",
            OrderStatus::Cancelled => "cancelled",
        };
        f.write_str(s)
    }
}
