use crate::status::OrderStatus;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OrderLine {
    pub sku: String,
    pub ordered: u32,
    pub shipped: u32,
    pub cancelled: bool,
}

impl OrderLine {
    pub fn new(sku: &str, ordered: u32) -> Self {
        OrderLine { sku: sku.to_string(), ordered, shipped: 0, cancelled: false }
    }

    pub fn outstanding(&self) -> u32 {
        if self.cancelled {
            0
        } else {
            self.ordered - self.shipped
        }
    }

    pub fn is_complete(&self) -> bool {
        self.outstanding() == 0
    }
}

#[derive(Debug, Clone)]
pub struct Order {
    pub id: u64,
    pub lines: Vec<OrderLine>,
    pub paid: bool,
    pub delivered: bool,
}

impl Order {
    pub fn new(id: u64) -> Self {
        Order { id, lines: Vec::new(), paid: false, delivered: false }
    }

    pub fn line(mut self, sku: &str, qty: u32) -> Self {
        self.lines.push(OrderLine::new(sku, qty));
        self
    }

    pub fn paid(mut self) -> Self {
        self.paid = true;
        self
    }

    pub fn line_mut(&mut self, sku: &str) -> Option<&mut OrderLine> {
        self.lines.iter_mut().find(|l| l.sku == sku)
    }

    pub fn units_outstanding(&self) -> u32 {
        self.lines.iter().map(|l| l.outstanding()).sum()
    }

    pub fn units_shipped(&self) -> u32 {
        self.lines.iter().map(|l| l.shipped).sum()
    }

    pub fn status(&self) -> OrderStatus {
        if !self.lines.is_empty() && self.lines.iter().all(|l| l.cancelled) {
            return OrderStatus::Cancelled;
        }
        if !self.paid {
            return OrderStatus::AwaitingPayment;
        }
        if self.delivered {
            return OrderStatus::Delivered;
        }
        if self.units_shipped() > 0 {
            return OrderStatus::Shipped;
        }
        OrderStatus::ReadyToShip
    }

    pub fn cancel_line(&mut self, sku: &str) -> bool {
        match self.line_mut(sku) {
            Some(l) if l.shipped == 0 => {
                l.cancelled = true;
                true
            }
            _ => false,
        }
    }
}
