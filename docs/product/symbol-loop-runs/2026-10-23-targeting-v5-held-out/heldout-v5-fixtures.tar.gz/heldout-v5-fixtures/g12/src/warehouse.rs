use std::collections::HashMap;
use std::fmt;

use crate::order::Order;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ShipError {
    NotPaid(u64),
    UnknownLine(String),
    TooMany { sku: String, requested: u32, outstanding: u32 },
    OutOfStock { sku: String, requested: u32, available: u32 },
}

impl fmt::Display for ShipError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ShipError::NotPaid(id) => write!(f, "order {id} is not paid"),
            ShipError::UnknownLine(s) => write!(f, "order has no line for {s}"),
            ShipError::TooMany { sku, requested, outstanding } => {
                write!(f, "cannot ship {requested} of {sku}, only {outstanding} outstanding")
            }
            ShipError::OutOfStock { sku, requested, available } => {
                write!(f, "cannot ship {requested} of {sku}, only {available} in stock")
            }
        }
    }
}

#[derive(Debug, Default)]
pub struct Warehouse {
    stock: HashMap<String, u32>,
}

impl Warehouse {
    pub fn new() -> Self {
        Warehouse::default()
    }

    pub fn stock(&mut self, sku: &str, qty: u32) {
        *self.stock.entry(sku.to_string()).or_insert(0) += qty;
    }

    pub fn available(&self, sku: &str) -> u32 {
        self.stock.get(sku).copied().unwrap_or(0)
    }

    pub fn ship(&mut self, order: &mut Order, sku: &str, qty: u32) -> Result<(), ShipError> {
        if !order.paid {
            return Err(ShipError::NotPaid(order.id));
        }
        let available = self.available(sku);
        let line = order.line_mut(sku).ok_or_else(|| ShipError::UnknownLine(sku.to_string()))?;
        if qty > line.outstanding() {
            return Err(ShipError::TooMany { sku: sku.to_string(), requested: qty, outstanding: line.outstanding() });
        }
        if qty > available {
            return Err(ShipError::OutOfStock { sku: sku.to_string(), requested: qty, available });
        }
        line.shipped += qty;
        self.stock.insert(sku.to_string(), available - qty);
        Ok(())
    }

    /// Ships everything outstanding that is in stock.
    pub fn ship_available(&mut self, order: &mut Order) -> Result<u32, ShipError> {
        let wanted: Vec<(String, u32)> = order.lines.iter().map(|l| (l.sku.clone(), l.outstanding())).collect();
        let mut total = 0;
        for (sku, outstanding) in wanted {
            let qty = outstanding.min(self.available(&sku));
            if qty > 0 {
                self.ship(order, &sku, qty)?;
                total += qty;
            }
        }
        Ok(total)
    }
}
