//! Order fulfilment state for a small web shop: order lines, shipping
//! against them, the derived order status, and customer notifications.

pub mod notify;
pub mod order;
pub mod status;
pub mod warehouse;

pub use notify::{Notifier, Email};
pub use order::{Order, OrderLine};
pub use status::OrderStatus;
pub use warehouse::{ShipError, Warehouse};
