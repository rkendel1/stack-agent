use fulfilkit::{Notifier, Order, ShipError, Warehouse};

fn stocked() -> Warehouse {
    let mut w = Warehouse::new();
    w.stock("MUG", 10);
    w.stock("TEE-M", 1);
    w
}

#[test]
fn unpaid_order_waits_for_payment() {
    let mut o = Order::new(1).line("MUG", 2);
    assert_eq!(o.status().to_string(), "awaiting_payment");
    assert_eq!(stocked().ship(&mut o, "MUG", 1), Err(ShipError::NotPaid(1)));
}

#[test]
fn fully_shipped_order() {
    let mut w = stocked();
    let mut o = Order::new(2).line("MUG", 3).paid();
    assert_eq!(o.status().to_string(), "ready_to_ship");
    assert_eq!(w.ship_available(&mut o).unwrap(), 3);
    assert_eq!(o.status().to_string(), "shipped");
    assert_eq!(w.available("MUG"), 7);
}

#[test]
fn partially_shipped_order_reports_partial_status() {
    let mut w = stocked();
    let mut o = Order::new(3).line("MUG", 1).line("TEE-M", 2).paid();
    assert_eq!(w.ship_available(&mut o).unwrap(), 2);
    assert_eq!(o.units_outstanding(), 1);
    let status = o.status();
    assert_eq!(status.to_string(), "partially_shipped");
    assert!(!status.is_final());
    assert_eq!(status.customer_message(), "Part of your order is on its way.");
}

#[test]
fn shipped_email_is_sent_once_everything_has_left() {
    let mut w = stocked();
    let mut n = Notifier::new();
    let mut o = Order::new(4).line("TEE-M", 2).paid();
    n.observe(&o);
    w.ship_available(&mut o).unwrap();
    n.observe(&o);
    assert_eq!(n.outbox.len(), 1, "no shipping email while items are still outstanding");
    w.stock("TEE-M", 5);
    w.ship_available(&mut o).unwrap();
    n.observe(&o);
    let subjects: Vec<&str> = n.outbox.iter().map(|e| e.subject.as_str()).collect();
    assert_eq!(subjects, vec!["Thanks for your payment", "Your order has shipped"]);
}

#[test]
fn cancelled_lines_do_not_count_as_outstanding() {
    let mut w = stocked();
    let mut o = Order::new(5).line("MUG", 1).line("TEE-M", 4).paid();
    assert!(o.cancel_line("TEE-M"));
    w.ship_available(&mut o).unwrap();
    assert_eq!(o.status().to_string(), "shipped");
    assert!(!o.cancel_line("MUG"));
}

#[test]
fn fully_cancelled_order() {
    let mut n = Notifier::new();
    let mut o = Order::new(6).line("MUG", 1).paid();
    n.observe(&o);
    o.cancel_line("MUG");
    n.observe(&o);
    assert_eq!(o.status().to_string(), "cancelled");
    assert!(o.status().is_final());
    assert_eq!(n.outbox.last().unwrap().subject, "Your order was cancelled");
}

#[test]
fn shipping_errors() {
    let mut w = stocked();
    let mut o = Order::new(7).line("TEE-M", 3).paid();
    assert!(matches!(w.ship(&mut o, "TEE-M", 4), Err(ShipError::TooMany { .. })));
    assert!(matches!(w.ship(&mut o, "TEE-M", 2), Err(ShipError::OutOfStock { available: 1, .. })));
    assert_eq!(w.ship(&mut o, "HAT", 1), Err(ShipError::UnknownLine("HAT".into())));
}
