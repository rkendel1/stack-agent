//! Print spooler: jobs wait in a priority queue and are handed to idle
//! printers, longest-idle printer first.

pub mod dispatch;
pub mod job;
pub mod printers;
pub mod queue;

pub use dispatch::{Assignment, Dispatcher};
pub use job::{Job, Priority};
pub use printers::{IdlePrinter, PrinterPool};
pub use queue::Spool;
