use std::cmp::Ordering;
use std::collections::BTreeSet;

/// A printer waiting for work. The longest-idle printer sorts first.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IdlePrinter {
    pub name: String,
    pub idle_since: u64,
    pub color: bool,
}

impl Ord for IdlePrinter {
    fn cmp(&self, other: &Self) -> Ordering {
        self.idle_since
            .cmp(&other.idle_since)
            .then_with(|| self.name.cmp(&other.name))
    }
}

impl PartialOrd for IdlePrinter {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[derive(Debug, Default)]
pub struct PrinterPool {
    idle: BTreeSet<IdlePrinter>,
}

impl PrinterPool {
    pub fn new() -> Self {
        PrinterPool { idle: BTreeSet::new() }
    }

    pub fn mark_idle(&mut self, name: &str, now: u64, color: bool) {
        self.idle.retain(|p| p.name != name);
        self.idle.insert(IdlePrinter { name: name.to_string(), idle_since: now, color });
    }

    pub fn idle_count(&self) -> usize {
        self.idle.len()
    }

    /// Takes the longest-idle printer that can print the job.
    pub fn take(&mut self, needs_color: bool) -> Option<IdlePrinter> {
        let pick = self.idle.iter().find(|p| p.color || !needs_color)?.clone();
        self.idle.remove(&pick);
        Some(pick)
    }
}
