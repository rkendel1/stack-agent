use crate::job::Job;
use crate::printers::PrinterPool;
use crate::queue::Spool;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Assignment {
    pub job_seq: u64,
    pub document: String,
    pub printer: String,
}

pub struct Dispatcher {
    pub spool: Spool,
    pub pool: PrinterPool,
}

impl Dispatcher {
    pub fn new(spool: Spool, pool: PrinterPool) -> Self {
        Dispatcher { spool, pool }
    }

    /// Hands queued jobs to idle printers until either runs out. Color jobs
    /// that find no color printer are held back and restored to the queue
    /// afterwards with their original place.
    pub fn run(&mut self) -> Vec<Assignment> {
        let mut out = Vec::new();
        let mut held: Vec<Job> = Vec::new();
        while self.pool.idle_count() > 0 {
            let job = match self.spool.next() {
                Some(j) => j,
                None => break,
            };
            match self.pool.take(job.color) {
                Some(p) => out.push(Assignment { job_seq: job.seq, document: job.document, printer: p.name }),
                None => held.push(job),
            }
        }
        for job in held {
            self.spool.restore(job);
        }
        out
    }

    /// Order in which the currently queued jobs would print, without
    /// consuming the queue.
    pub fn preview(&mut self) -> Vec<u64> {
        let mut taken = Vec::new();
        while let Some(j) = self.spool.next() {
            taken.push(j);
        }
        let order = taken.iter().map(|j| j.seq).collect();
        for j in taken {
            self.spool.restore(j);
        }
        order
    }
}
