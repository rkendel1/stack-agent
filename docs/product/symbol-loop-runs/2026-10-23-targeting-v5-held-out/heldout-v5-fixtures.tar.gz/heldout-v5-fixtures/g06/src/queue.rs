use std::collections::BinaryHeap;

use crate::job::{Job, Priority};

#[derive(Debug, Default)]
pub struct Spool {
    heap: BinaryHeap<Job>,
    next_seq: u64,
    max_pages: Option<u32>,
}

impl Spool {
    pub fn new() -> Self {
        Spool { heap: BinaryHeap::new(), next_seq: 1, max_pages: None }
    }

    pub fn with_page_limit(mut self, max_pages: u32) -> Self {
        self.max_pages = Some(max_pages);
        self
    }

    /// Queues a job and returns its sequence number.
    pub fn submit(&mut self, mut job: Job) -> Result<u64, String> {
        if job.pages == 0 {
            return Err(format!("{} has no pages", job.document));
        }
        if let Some(limit) = self.max_pages {
            if job.pages > limit {
                return Err(format!("{} exceeds the {limit} page limit", job.document));
            }
        }
        if self.next_seq == 0 {
            self.next_seq = 1;
        }
        job.seq = self.next_seq;
        self.next_seq += 1;
        self.heap.push(job);
        Ok(self.next_seq - 1)
    }

    /// Puts a previously dequeued job back, keeping its sequence number.
    pub fn restore(&mut self, job: Job) {
        self.heap.push(job);
    }

    pub fn next(&mut self) -> Option<Job> {
        self.heap.pop()
    }

    pub fn peek(&self) -> Option<&Job> {
        self.heap.peek()
    }

    pub fn len(&self) -> usize {
        self.heap.len()
    }

    pub fn is_empty(&self) -> bool {
        self.heap.is_empty()
    }

    /// Removes every queued job of `owner`, returning how many were removed.
    pub fn cancel_owner(&mut self, owner: &str) -> usize {
        let before = self.heap.len();
        let kept: Vec<Job> = self.heap.drain().filter(|j| j.owner != owner).collect();
        self.heap.extend(kept);
        before - self.heap.len()
    }

    pub fn pending_pages(&self, at_least: Priority) -> u32 {
        self.heap.iter().filter(|j| j.priority >= at_least).map(|j| j.pages).sum()
    }
}
