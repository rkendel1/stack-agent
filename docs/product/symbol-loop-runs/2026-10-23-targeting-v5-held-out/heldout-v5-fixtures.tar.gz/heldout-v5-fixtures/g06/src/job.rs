use std::cmp::Ordering;
use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Priority {
    Low,
    Normal,
    High,
    Urgent,
}

impl Priority {
    pub fn parse(s: &str) -> Option<Priority> {
        match s {
            "low" => Some(Priority::Low),
            "normal" | "" => Some(Priority::Normal),
            "high" => Some(Priority::High),
            "urgent" => Some(Priority::Urgent),
            _ => None,
        }
    }
}

/// A queued print job. `seq` is assigned by the spool on submission.
#[derive(Debug, Clone)]
pub struct Job {
    pub seq: u64,
    pub owner: String,
    pub document: String,
    pub pages: u32,
    pub priority: Priority,
    pub color: bool,
}

impl Job {
    pub fn new(owner: &str, document: &str, pages: u32) -> Self {
        Job {
            seq: 0,
            owner: owner.to_string(),
            document: document.to_string(),
            pages,
            priority: Priority::Normal,
            color: false,
        }
    }

    pub fn priority(mut self, p: Priority) -> Self {
        self.priority = p;
        self
    }

    pub fn color(mut self) -> Self {
        self.color = true;
        self
    }
}

impl fmt::Display for Job {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "#{} {}:{} ({}p)", self.seq, self.owner, self.document, self.pages)
    }
}

impl PartialEq for Job {
    fn eq(&self, other: &Self) -> bool {
        self.seq == other.seq
    }
}

impl Eq for Job {}

/// Jobs order by priority; among equal priorities the job submitted first
/// is the greatest, so that a max-heap pops it first.
impl Ord for Job {
    fn cmp(&self, other: &Self) -> Ordering {
        self.priority
            .cmp(&other.priority)
            .then_with(|| self.seq.cmp(&other.seq))
    }
}

impl PartialOrd for Job {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}
