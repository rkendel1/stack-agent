use printspool::{Dispatcher, Job, Priority, PrinterPool, Spool};

fn pool(names: &[(&str, u64, bool)]) -> PrinterPool {
    let mut p = PrinterPool::new();
    for (n, t, c) in names {
        p.mark_idle(n, *t, *c);
    }
    p
}

#[test]
fn higher_priority_prints_first() {
    let mut s = Spool::new();
    s.submit(Job::new("ann", "memo.txt", 1)).unwrap();
    s.submit(Job::new("bob", "contract.pdf", 12).priority(Priority::Urgent)).unwrap();
    s.submit(Job::new("cy", "flyer.png", 2).priority(Priority::Low)).unwrap();
    let docs: Vec<String> = std::iter::from_fn(|| s.next()).map(|j| j.document).collect();
    assert_eq!(docs, vec!["contract.pdf", "memo.txt", "flyer.png"]);
}

#[test]
fn same_priority_jobs_print_in_submission_order() {
    let mut s = Spool::new();
    for doc in ["a.pdf", "b.pdf", "c.pdf"] {
        s.submit(Job::new("ann", doc, 3)).unwrap();
    }
    let mut d = Dispatcher::new(s, pool(&[("lobby", 10, false), ("office", 20, false), ("lab", 30, false)]));
    let got: Vec<(String, String)> = d.run().into_iter().map(|a| (a.document, a.printer)).collect();
    assert_eq!(
        got,
        vec![
            ("a.pdf".to_string(), "lobby".to_string()),
            ("b.pdf".to_string(), "office".to_string()),
            ("c.pdf".to_string(), "lab".to_string()),
        ]
    );
}

#[test]
fn preview_orders_by_priority_then_age() {
    let mut s = Spool::new();
    s.submit(Job::new("a", "1", 1).priority(Priority::High)).unwrap();
    s.submit(Job::new("b", "2", 1)).unwrap();
    s.submit(Job::new("c", "3", 1).priority(Priority::High)).unwrap();
    s.submit(Job::new("d", "4", 1)).unwrap();
    let mut d = Dispatcher::new(s, PrinterPool::new());
    assert_eq!(d.preview(), vec![1, 3, 2, 4]);
    assert_eq!(d.spool.len(), 4);
}

#[test]
fn color_job_waits_for_color_printer() {
    let mut s = Spool::new();
    s.submit(Job::new("ann", "photo.jpg", 1).color().priority(Priority::High)).unwrap();
    s.submit(Job::new("bob", "notes.txt", 4)).unwrap();
    let mut d = Dispatcher::new(s, pool(&[("mono", 5, false)]));
    let a = d.run();
    assert_eq!(a.len(), 1);
    assert_eq!(a[0].document, "notes.txt");
    assert_eq!(d.spool.peek().map(|j| j.document.as_str()), Some("photo.jpg"));
}

#[test]
fn longest_idle_printer_gets_the_job() {
    let mut p = pool(&[("b", 50, true), ("a", 50, false), ("c", 10, false)]);
    assert_eq!(p.take(false).unwrap().name, "c");
    assert_eq!(p.take(false).unwrap().name, "a");
    assert_eq!(p.take(true).unwrap().name, "b");
    assert!(p.take(false).is_none());
}

#[test]
fn page_limit_and_cancellation() {
    let mut s = Spool::new().with_page_limit(50);
    assert!(s.submit(Job::new("ann", "thesis.pdf", 300)).is_err());
    assert!(s.submit(Job::new("ann", "empty", 0)).is_err());
    s.submit(Job::new("ann", "x", 10)).unwrap();
    s.submit(Job::new("bob", "y", 20).priority(Priority::High)).unwrap();
    s.submit(Job::new("ann", "z", 5)).unwrap();
    assert_eq!(s.pending_pages(Priority::Normal), 35);
    assert_eq!(s.cancel_owner("ann"), 2);
    assert_eq!(s.next().unwrap().document, "y");
}
