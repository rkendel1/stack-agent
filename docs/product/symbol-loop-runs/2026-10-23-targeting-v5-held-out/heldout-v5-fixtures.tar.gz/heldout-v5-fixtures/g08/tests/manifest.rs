use parcelrate::{parse_manifest, price_manifest, RateCard, Zone};

#[test]
fn small_parcels_local_zone() {
    let m = parse_manifest("depot 30 to 3050\nA1; 400; 20x15x5\nA2; 1800; 30x20x10\n").unwrap();
    assert_eq!(m.zone, Zone::Local);
    let (q, refused) = price_manifest(&RateCard::default(), &m);
    assert!(refused.is_empty());
    assert_eq!(q.iter().map(|q| q.cents).collect::<Vec<_>>(), vec![450, 790]);
}

#[test]
fn volumetric_weight_wins_for_light_boxes() {
    let m = parse_manifest("depot 30 to 3999\nPILLOW; 900; 50x40x30\n").unwrap();
    let (q, _) = price_manifest(&RateCard::default(), &m);
    assert_eq!(q[0].billable_grams, 12_000);
    assert_eq!(q[0].cents, 3_490 * 125 / 100);
}

#[test]
fn heavy_pallet_is_priced_in_top_band() {
    let m = parse_manifest("depot 30 to 2000\n# machine parts\nPAL-1; 72500; 80x60x40\n").unwrap();
    assert!((m.total_weight_kg() - 72.5).abs() < 1e-9);
    let (q, refused) = price_manifest(&RateCard::default(), &m);
    assert!(refused.is_empty());
    assert_eq!(q[0].billable_grams, 72_500);
    assert_eq!(q[0].cents, 9_900 * 160 / 100);
}

#[test]
fn bulky_box_billed_by_volume() {
    let m = parse_manifest("depot 30 to 3121\nSOFA; 41000; 200x80x60\n").unwrap();
    let (q, refused) = price_manifest(&RateCard::default(), &m);
    assert!(q.is_empty());
    assert_eq!(refused, vec!["SOFA".to_string()]);
    let m = parse_manifest("depot 30 to 3121\nCHAIR; 21000; 100x80x60\n").unwrap();
    let (q, refused) = price_manifest(&RateCard::default(), &m);
    assert!(refused.is_empty());
    assert_eq!(q[0].billable_grams, 96_000);
    assert_eq!(q[0].cents, 9_900 * 125 / 100 + 2_500);
}

#[test]
fn overweight_parcel_is_refused() {
    let m = parse_manifest("depot 30 to 0800\nOK; 1000; 10x10x10\nBIG; 60000; 250x100x100\n").unwrap();
    assert_eq!(m.zone, Zone::Remote);
    let (q, refused) = price_manifest(&RateCard::default(), &m);
    assert_eq!(q.len(), 1);
    assert_eq!(refused, vec!["BIG".to_string()]);
}

#[test]
fn bad_lines_report_line_numbers() {
    let e = parse_manifest("depot 30 to 3000\nA; 10; 1x1x1\nB; ten; 1x1x1\n").unwrap_err();
    assert_eq!(e.line, 3);
    let e = parse_manifest("depot 30 to 3000\nA; 10; 1x1x1\nA; 10; 1x1x1\n").unwrap_err();
    assert!(e.message.contains("duplicate"));
    assert!(parse_manifest("from 30 to 3000\n").is_err());
}
