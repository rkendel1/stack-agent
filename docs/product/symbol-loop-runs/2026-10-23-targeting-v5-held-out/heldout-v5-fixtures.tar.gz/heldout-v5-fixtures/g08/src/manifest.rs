use std::fmt;

use crate::parcel::Parcel;
use crate::zones::Zone;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ManifestError {
    pub line: usize,
    pub message: String,
}

impl fmt::Display for ManifestError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "manifest line {}: {}", self.line, self.message)
    }
}

#[derive(Debug, Clone)]
pub struct Manifest {
    pub depot: String,
    pub postcode: String,
    pub zone: Zone,
    pub parcels: Vec<Parcel>,
}

impl Manifest {
    pub fn total_weight_kg(&self) -> f64 {
        self.parcels.iter().map(|p| p.weight_grams as u64).sum::<u64>() as f64 / 1000.0
    }
}

fn err(line: usize, message: impl Into<String>) -> ManifestError {
    ManifestError { line, message: message.into() }
}

fn parse_dims(s: &str) -> Option<(u16, u16, u16)> {
    let parts: Vec<u16> = s.split('x').map(|p| p.trim().parse().ok()).collect::<Option<_>>()?;
    match parts.as_slice() {
        [l, w, h] if *l > 0 && *w > 0 && *h > 0 => Some((*l, *w, *h)),
        _ => None,
    }
}

fn parse_parcel(line_no: usize, line: &str) -> Result<Parcel, ManifestError> {
    let fields: Vec<&str> = line.split(';').map(str::trim).collect();
    if fields.len() != 3 {
        return Err(err(line_no, "expected id;grams;LxWxH"));
    }
    let weight_grams = fields[1]
        .parse()
        .map_err(|e| err(line_no, format!("bad weight '{}': {e}", fields[1])))?;
    let (length_cm, width_cm, height_cm) =
        parse_dims(fields[2]).ok_or_else(|| err(line_no, format!("bad dimensions '{}'", fields[2])))?;
    Ok(Parcel { id: fields[0].to_string(), weight_grams, length_cm, width_cm, height_cm })
}

/// Format:
///
/// ```text
/// depot 30 to 3150
/// P1; 1200; 30x20x10
/// ```
pub fn parse_manifest(text: &str) -> Result<Manifest, ManifestError> {
    let mut lines = text.lines().enumerate().filter(|(_, l)| !l.trim().is_empty() && !l.trim().starts_with('#'));
    let (n, header) = lines.next().ok_or_else(|| err(1, "empty manifest"))?;
    let words: Vec<&str> = header.split_whitespace().collect();
    let (depot, postcode) = match words.as_slice() {
        ["depot", d, "to", pc] => (d.to_string(), pc.to_string()),
        _ => return Err(err(n + 1, "expected 'depot <prefix> to <postcode>'")),
    };
    let zone = Zone::for_postcode(&depot, &postcode).ok_or_else(|| err(n + 1, format!("bad postcode {postcode}")))?;
    let mut parcels = Vec::new();
    for (i, line) in lines {
        let p = parse_parcel(i + 1, line)?;
        if parcels.iter().any(|q: &Parcel| q.id == p.id) {
            return Err(err(i + 1, format!("duplicate parcel id {}", p.id)));
        }
        parcels.push(p);
    }
    Ok(Manifest { depot, postcode, zone, parcels })
}
