#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Zone {
    Local,
    Regional,
    National,
    Remote,
}

impl Zone {
    /// Zone of a destination postcode relative to the depot at `depot_prefix`.
    pub fn for_postcode(depot_prefix: &str, postcode: &str) -> Option<Zone> {
        let pc = postcode.trim();
        if pc.len() < 4 || !pc.chars().all(|c| c.is_ascii_digit()) {
            return None;
        }
        if pc.starts_with('0') || pc.starts_with("98") || pc.starts_with("99") {
            return Some(Zone::Remote);
        }
        if pc.starts_with(depot_prefix) {
            return Some(Zone::Local);
        }
        if pc.chars().next() == depot_prefix.chars().next() {
            return Some(Zone::Regional);
        }
        Some(Zone::National)
    }

    /// Multiplier in percent applied to the base band price.
    pub fn multiplier_pct(&self) -> u32 {
        match self {
            Zone::Local => 100,
            Zone::Regional => 125,
            Zone::National => 160,
            Zone::Remote => 240,
        }
    }
}
