//! Shipping cost calculation for a courier manifest: parse the manifest,
//! work out billable weight, and price each parcel by zone and weight band.

pub mod manifest;
pub mod parcel;
pub mod rates;
pub mod zones;

pub use manifest::{parse_manifest, Manifest, ManifestError};
pub use parcel::Parcel;
pub use rates::{RateCard, Quote};
pub use zones::Zone;

/// Prices every parcel in a manifest. Parcels that cannot be carried are
/// returned separately by id.
pub fn price_manifest(card: &RateCard, manifest: &Manifest) -> (Vec<Quote>, Vec<String>) {
    let mut quotes = Vec::new();
    let mut refused = Vec::new();
    for p in &manifest.parcels {
        match card.quote(p, manifest.zone) {
            Some(q) => quotes.push(q),
            None => refused.push(p.id.clone()),
        }
    }
    (quotes, refused)
}
