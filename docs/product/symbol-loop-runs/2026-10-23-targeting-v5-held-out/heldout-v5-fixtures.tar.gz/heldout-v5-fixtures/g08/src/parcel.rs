/// Divisor turning cubic centimetres into volumetric grams (5000 cm3 per kg).
pub const VOLUMETRIC_DIVISOR: u32 = 5;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Parcel {
    pub id: String,
    pub weight_grams: u16,
    pub length_cm: u16,
    pub width_cm: u16,
    pub height_cm: u16,
}

impl Parcel {
    pub fn volume_cm3(&self) -> u32 {
        self.length_cm as u32 * self.width_cm as u32 * self.height_cm as u32
    }

    pub fn volumetric_grams(&self) -> u32 {
        self.volume_cm3() / VOLUMETRIC_DIVISOR
    }

    /// The weight the courier charges for: the greater of actual and
    /// volumetric weight.
    pub fn billable_grams(&self) -> u16 {
        let actual = self.weight_grams as u32;
        let billable = actual.max(self.volumetric_grams());
        billable.min(u16::MAX as u32) as u16
    }

    /// Longest side plus girth, used for the oversize check.
    pub fn length_plus_girth(&self) -> u32 {
        let mut sides = [self.length_cm as u32, self.width_cm as u32, self.height_cm as u32];
        sides.sort_unstable();
        sides[2] + 2 * (sides[0] + sides[1])
    }
}
