use crate::parcel::Parcel;
use crate::zones::Zone;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Quote {
    pub parcel_id: String,
    pub billable_grams: u32,
    pub cents: u32,
}

/// Weight bands: each entry is (max grams inclusive, base price in cents).
#[derive(Debug, Clone)]
pub struct RateCard {
    bands: Vec<(u32, u32)>,
    oversize_cm: u32,
    oversize_fee: u32,
}

impl Default for RateCard {
    fn default() -> Self {
        RateCard {
            bands: vec![
                (500, 450),
                (2_000, 790),
                (5_000, 1_290),
                (10_000, 1_990),
                (30_000, 3_490),
                (70_000, 6_900),
                (100_000, 9_900),
            ],
            oversize_cm: 300,
            oversize_fee: 2_500,
        }
    }
}

impl RateCard {
    pub fn band_price(&self, grams: u32) -> Option<u32> {
        self.bands.iter().find(|(max, _)| grams <= *max).map(|(_, cents)| *cents)
    }

    pub fn max_grams(&self) -> u32 {
        self.bands.last().map(|(m, _)| *m).unwrap_or(0)
    }

    pub fn quote(&self, parcel: &Parcel, zone: Zone) -> Option<Quote> {
        let grams = parcel.billable_grams() as u32;
        let base = self.band_price(grams)?;
        let mut cents = base * zone.multiplier_pct() / 100;
        if parcel.length_plus_girth() > self.oversize_cm {
            cents += self.oversize_fee;
        }
        Some(Quote { parcel_id: parcel.id.clone(), billable_grams: grams, cents })
    }
}
