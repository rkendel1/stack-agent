use std::collections::BTreeMap;

use crate::date::Date;
use crate::ledger::Ledger;
use crate::money::Amount;

/// One line per account: `account  balance`, aligned, with a total line.
pub fn balance_report(ledger: &Ledger, as_of: Date) -> String {
    let accounts = ledger.accounts();
    let width = accounts.iter().map(|a| a.len()).max().unwrap_or(0).max(5);
    let mut out = format!("Balances as of {as_of}\n");
    let mut total = Amount::ZERO;
    for a in accounts {
        let bal = ledger.balance_as_of(a, as_of);
        total += bal;
        out.push_str(&format!("{:<width$}  {:>10}\n", a, bal.to_string(), width = width));
    }
    out.push_str(&format!("{:<width$}  {:>10}\n", "TOTAL", total.to_string(), width = width));
    out
}

/// Net movement per (year, month) for one account.
pub fn monthly_totals(ledger: &Ledger, account: &str) -> BTreeMap<(i32, u8), Amount> {
    let mut map = BTreeMap::new();
    for e in ledger.entries_for(account) {
        *map.entry(e.date.month_key()).or_insert(Amount::ZERO) += e.amount;
    }
    map
}
