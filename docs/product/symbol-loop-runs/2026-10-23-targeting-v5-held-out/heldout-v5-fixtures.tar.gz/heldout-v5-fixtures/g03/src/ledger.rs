use std::collections::BTreeMap;

use crate::date::Date;
use crate::money::Amount;

#[derive(Debug, Clone, PartialEq)]
pub struct Entry {
    pub date: Date,
    pub account: String,
    pub amount: Amount,
    pub memo: String,
}

#[derive(Debug, Default, Clone)]
pub struct Ledger {
    entries: Vec<Entry>,
    opening: BTreeMap<String, Amount>,
}

impl Ledger {
    pub fn new() -> Self {
        Ledger::default()
    }

    pub fn open_account(&mut self, account: &str, opening: Amount) {
        self.opening.insert(account.to_string(), opening);
    }

    pub fn post(&mut self, entry: Entry) {
        self.opening.entry(entry.account.clone()).or_insert(Amount::ZERO);
        let pos = self.entries.partition_point(|e| e.date <= entry.date);
        self.entries.insert(pos, entry);
    }

    pub fn entries(&self) -> &[Entry] {
        &self.entries
    }

    pub fn accounts(&self) -> Vec<&str> {
        self.opening.keys().map(|k| k.as_str()).collect()
    }

    pub fn entries_for<'a>(&'a self, account: &'a str) -> impl Iterator<Item = &'a Entry> + 'a {
        self.entries.iter().filter(move |e| e.account == account)
    }

    /// Balance of `account` including every entry dated on or before `cutoff`.
    pub fn balance_as_of(&self, account: &str, cutoff: Date) -> Amount {
        let opening = self.opening.get(account).copied().unwrap_or(Amount::ZERO);
        let moved: Amount = self
            .entries_for(account)
            .filter(|e| e.date < cutoff)
            .map(|e| e.amount)
            .sum();
        opening + moved
    }

    pub fn balance(&self, account: &str) -> Amount {
        let opening = self.opening.get(account).copied().unwrap_or(Amount::ZERO);
        opening + self.entries_for(account).map(|e| e.amount).sum()
    }

    pub fn transfer(&mut self, date: Date, from: &str, to: &str, amount: Amount, memo: &str) {
        self.post(Entry { date, account: from.to_string(), amount: -amount, memo: memo.to_string() });
        self.post(Entry { date, account: to.to_string(), amount, memo: memo.to_string() });
    }
}
