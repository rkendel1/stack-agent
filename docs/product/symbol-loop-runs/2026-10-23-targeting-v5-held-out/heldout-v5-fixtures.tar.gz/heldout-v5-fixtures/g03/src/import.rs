use std::fmt;

use crate::date::Date;
use crate::ledger::{Entry, Ledger};
use crate::money::parse_amount;

#[derive(Debug, Clone, PartialEq)]
pub struct ImportError {
    pub line: usize,
    pub reason: String,
}

impl fmt::Display for ImportError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "line {}: {}", self.line, self.reason)
    }
}

fn parse_line(line: &str) -> Result<Entry, String> {
    let parts: Vec<&str> = line.split(';').map(|p| p.trim()).collect();
    if parts.len() < 3 {
        return Err(format!("expected date;account;amount[;memo], got '{line}'"));
    }
    let date = Date::parse(parts[0]).ok_or_else(|| format!("bad date '{}'", parts[0]))?;
    if parts[1].is_empty() {
        return Err("missing account".to_string());
    }
    let amount = parse_amount(parts[2])?;
    let memo = parts.get(3).map(|m| m.to_string()).unwrap_or_default();
    Ok(Entry { date, account: parts[1].to_string(), amount, memo })
}

/// Imports a statement. Blank lines and lines starting with `#` are skipped.
/// Returns the number of entries posted.
pub fn import_statement(ledger: &mut Ledger, text: &str) -> Result<usize, ImportError> {
    let mut parsed = Vec::new();
    for (i, raw) in text.lines().enumerate() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let entry = parse_line(line).map_err(|reason| ImportError { line: i + 1, reason })?;
        parsed.push(entry);
    }
    let n = parsed.len();
    for e in parsed {
        ledger.post(e);
    }
    Ok(n)
}
