use tallyledger::{balance_report, import_statement, monthly_totals, parse_amount, Amount, Date, Ledger};

const STATEMENT: &str = "\
# march statement
2024-03-01; checking; 2,500.00; salary
2024-03-03; checking; -84.20; groceries
2024-03-15; checking; -1200; rent
2024-03-15; savings; 300; standing order
2024-03-31; checking; -0.75; bank fee
2024-04-02; checking; 19.99; refund
";

fn d(s: &str) -> Date {
    Date::parse(s).unwrap()
}

fn loaded() -> Ledger {
    let mut l = Ledger::new();
    l.open_account("checking", Amount(10_000));
    import_statement(&mut l, STATEMENT).unwrap();
    l
}

#[test]
fn parses_positive_amounts() {
    assert_eq!(parse_amount("12").unwrap(), Amount(1200));
    assert_eq!(parse_amount("12.5").unwrap(), Amount(1250));
    assert_eq!(parse_amount("1,250.07").unwrap(), Amount(125007));
    assert!(parse_amount("1.234").is_err());
}

#[test]
fn imported_negative_amounts_keep_their_cents() {
    let l = loaded();
    let fee = l.entries().iter().find(|e| e.memo == "bank fee").unwrap();
    assert_eq!(fee.amount, Amount(-75));
    let groceries = l.entries().iter().find(|e| e.memo == "groceries").unwrap();
    assert_eq!(groceries.amount.to_string(), "-84.20");
}

#[test]
fn final_balance_of_checking() {
    let l = loaded();
    assert_eq!(l.balance("checking"), Amount(10_000 + 250_000 - 8_420 - 120_000 - 75 + 1_999));
}

#[test]
fn balance_includes_entries_on_cutoff_day() {
    let l = loaded();
    assert_eq!(l.balance_as_of("savings", d("2024-03-15")), Amount(30_000));
    assert_eq!(l.balance_as_of("savings", d("2024-03-14")), Amount(0));
}

#[test]
fn month_end_report() {
    let mut l = Ledger::new();
    l.open_account("cash", Amount(5_000));
    l.transfer(d("2024-01-10"), "cash", "wallet", Amount(2_000), "atm");
    l.transfer(d("2024-01-31"), "wallet", "cash", Amount(500), "change");
    let r = balance_report(&l, d("2024-01-31"));
    assert_eq!(r, "Balances as of 2024-01-31\ncash         35.00\nwallet       15.00\nTOTAL        50.00\n");
}

#[test]
fn monthly_totals_group_by_month() {
    let mut l = Ledger::new();
    import_statement(&mut l, "2024-03-01;cash;10\n2024-03-09;cash;5\n2024-04-01;cash;7\n").unwrap();
    let m = monthly_totals(&l, "cash");
    assert_eq!(m.get(&(2024, 3)), Some(&Amount(1500)));
    assert_eq!(m.get(&(2024, 4)), Some(&Amount(700)));
}

#[test]
fn import_reports_bad_line_number() {
    let mut l = Ledger::new();
    let err = import_statement(&mut l, "2024-01-01;cash;1\n\n2024-02-30;cash;2\n").unwrap_err();
    assert_eq!(err.line, 3);
    assert!(l.entries().is_empty());
}
