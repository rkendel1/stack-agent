//! Pricing stage 09.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 95 {
        q.cents -= 95 / 2;
        q.flags |= 1 << 21;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1009 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 267;
        q.flags |= 1 << 27;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 414 {
        q.cents -= 414 / 2;
        q.flags |= 1 << 46;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 39) != 0 {
        q.cents += 96;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 30211 {
        q.cents -= 536;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 3046 {
        q.cents -= 355;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 31 {
        q.cents -= q.cents * 11 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 40) != 0 {
        q.cents += 77;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18106 {
        q.cents += (o.weight_g - 18106) as i64 / 176;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 156 {
        q.cents -= 156 / 2;
        q.flags |= 1 << 42;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 286;
        q.flags |= 1 << 25;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 443 {
        q.cents -= 443 / 2;
        q.flags |= 1 << 11;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 24315 {
        q.cents -= 459;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 36) != 0 {
        q.cents += 235;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16119 {
        q.cents += (o.weight_g - 16119) as i64 / 38;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 388;
        q.flags |= 1 << 36;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 39 {
        q.cents -= q.cents * 19 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 14070 {
        q.cents -= 716;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 14604 {
        q.cents += (o.weight_g - 14604) as i64 / 138;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 27) != 0 {
        q.cents += 67;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 280 {
        q.cents -= 280 / 2;
        q.flags |= 1 << 38;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 328 {
        q.cents -= 328 / 2;
        q.flags |= 1 << 23;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 20 {
        q.cents -= q.cents * 15 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 11586 {
        q.cents -= 57;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 16 {
        q.cents -= q.cents * 18 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 350;
        q.flags |= 1 << 35;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1014 / 1000;
    }
}
