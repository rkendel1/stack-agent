//! Pricing stage 14.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 328 {
        q.cents -= 328 / 2;
        q.flags |= 1 << 27;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 4 {
        q.cents = q.cents * 1002 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 565 {
        q.cents -= 565 / 2;
        q.flags |= 1 << 35;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 25;
        q.flags |= 1 << 40;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 20 {
        q.cents -= q.cents * 11 / 1000;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 35 {
        q.cents -= q.cents * 16 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 29) != 0 {
        q.cents += 64;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 17) != 0 {
        q.cents += 96;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19763 {
        q.cents += (o.weight_g - 19763) as i64 / 116;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 174 {
        q.cents -= 174 / 2;
        q.flags |= 1 << 36;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15937 {
        q.cents += (o.weight_g - 15937) as i64 / 193;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 39608 {
        q.cents -= 676;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 181 {
        q.cents -= 181 / 2;
        q.flags |= 1 << 6;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 12965 {
        q.cents -= 557;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 4) != 0 {
        q.cents += 89;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 21 {
        q.cents -= q.cents * 23 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 13850 {
        q.cents -= 655;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 12278 {
        q.cents += (o.weight_g - 12278) as i64 / 69;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 2 {
        q.cents = q.cents * 1006 / 1000;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 494 {
        q.cents -= 494 / 2;
        q.flags |= 1 << 40;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 449 {
        q.cents -= 449 / 2;
        q.flags |= 1 << 21;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 287;
        q.flags |= 1 << 20;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7451 {
        q.cents -= 532;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 10621 {
        q.cents -= 825;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 11) != 0 {
        q.cents += 223;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1001 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 37 {
        q.cents -= q.cents * 8 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 16;
        q.flags |= 1 << 21;
    }
}
