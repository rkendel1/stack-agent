//! Pricing stage 17.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1007 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 224 {
        q.cents -= 224 / 2;
        q.flags |= 1 << 27;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 47) != 0 {
        q.cents += 75;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18553 {
        q.cents += (o.weight_g - 18553) as i64 / 30;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1002 / 1000;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 29 {
        q.cents -= q.cents * 23 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1009 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 374 {
        q.cents -= 374 / 2;
        q.flags |= 1 << 42;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 22020 {
        q.cents -= 118;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1002 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 43) != 0 {
        q.cents += 173;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 46) != 0 {
        q.cents += 103;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 4743 {
        q.cents -= 792;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 200 {
        q.cents -= 200 / 2;
        q.flags |= 1 << 11;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 4 {
        q.cents -= q.cents * 10 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10137 {
        q.cents += (o.weight_g - 10137) as i64 / 82;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18962 {
        q.cents += (o.weight_g - 18962) as i64 / 54;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 27342 {
        q.cents -= 698;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 36717 {
        q.cents -= 212;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7698 {
        q.cents += (o.weight_g - 7698) as i64 / 196;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 524 {
        q.cents -= 524 / 2;
        q.flags |= 1 << 26;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 32 {
        q.cents -= q.cents * 5 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 23381 {
        q.cents -= 645;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 121;
        q.flags |= 1 << 22;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 15070 {
        q.cents -= 704;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 8886 {
        q.cents += (o.weight_g - 8886) as i64 / 26;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 583 {
        q.cents -= 583 / 2;
        q.flags |= 1 << 39;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18227 {
        q.cents += (o.weight_g - 18227) as i64 / 145;
    }
}
