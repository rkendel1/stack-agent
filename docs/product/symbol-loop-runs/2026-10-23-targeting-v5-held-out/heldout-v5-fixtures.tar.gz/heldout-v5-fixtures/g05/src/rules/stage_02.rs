//! Pricing stage 02.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 23) != 0 {
        q.cents += 151;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 22 {
        q.cents -= q.cents * 13 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 17786 {
        q.cents += (o.weight_g - 17786) as i64 / 100;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 26994 {
        q.cents -= 243;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1007 / 1000;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 5 {
        q.cents = q.cents * 1006 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1004 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 436 {
        q.cents -= 436 / 2;
        q.flags |= 1 << 30;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5773 {
        q.cents += (o.weight_g - 5773) as i64 / 169;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7323 {
        q.cents -= 305;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 45) != 0 {
        q.cents += 132;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 128;
        q.flags |= 1 << 45;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 43) != 0 {
        q.cents += 117;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 0 {
        q.cents = q.cents * 1005 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 24) != 0 {
        q.cents += 117;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 28 {
        q.cents -= q.cents * 20 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7703 {
        q.cents += (o.weight_g - 7703) as i64 / 191;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 111 {
        q.cents -= 111 / 2;
        q.flags |= 1 << 1;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 553 {
        q.cents -= 553 / 2;
        q.flags |= 1 << 7;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2063 {
        q.cents += (o.weight_g - 2063) as i64 / 22;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 5 {
        q.cents -= q.cents * 13 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 36) != 0 {
        q.cents += 4;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 386 {
        q.cents -= 386 / 2;
        q.flags |= 1 << 9;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 89;
        q.flags |= 1 << 38;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 14 {
        q.cents -= q.cents * 14 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 12) != 0 {
        q.cents += 114;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 0) != 0 {
        q.cents += 72;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7253 {
        q.cents += (o.weight_g - 7253) as i64 / 24;
    }
}
