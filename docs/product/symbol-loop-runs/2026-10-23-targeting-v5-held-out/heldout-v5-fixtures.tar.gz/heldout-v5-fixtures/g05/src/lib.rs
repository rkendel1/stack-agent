//! Quote engine for a parts distributor. An order is priced from a base
//! rate and then passed through thirty stages of business rules.

pub mod engine;
pub mod model;
pub mod rules;

pub use engine::{base_price, evaluate, Breakdown};
pub use model::{Order, Quote};

/// Prices an order and returns the final quote.
pub fn price(order: &Order) -> Quote {
    evaluate(order).quote
}

/// Prices several orders, preserving order.
pub fn price_all(orders: &[Order]) -> Vec<Quote> {
    orders.iter().map(price).collect()
}
