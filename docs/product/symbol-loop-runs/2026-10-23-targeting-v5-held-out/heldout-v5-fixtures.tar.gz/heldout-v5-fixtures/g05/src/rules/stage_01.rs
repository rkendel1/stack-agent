//! Pricing stage 01.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 451 {
        q.cents -= 451 / 2;
        q.flags |= 1 << 13;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15940 {
        q.cents += (o.weight_g - 15940) as i64 / 196;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 13 {
        q.cents -= q.cents * 15 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 150;
        q.flags |= 1 << 9;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 411 {
        q.cents -= 411 / 2;
        q.flags |= 1 << 11;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1012 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 36 {
        q.cents -= q.cents * 4 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 0 {
        q.cents = q.cents * 1004 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2374 {
        q.cents += (o.weight_g - 2374) as i64 / 185;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 0 {
        q.cents = q.cents * 1002 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 286;
        q.flags |= 1 << 31;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 514 {
        q.cents -= 514 / 2;
        q.flags |= 1 << 40;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 59;
        q.flags |= 1 << 8;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 4128 {
        q.cents += (o.weight_g - 4128) as i64 / 114;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 37679 {
        q.cents -= 302;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 0 {
        q.cents = q.cents * 1012 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16667 {
        q.cents += (o.weight_g - 16667) as i64 / 123;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 484 {
        q.cents -= 484 / 2;
        q.flags |= 1 << 3;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 43) != 0 {
        q.cents += 117;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1012 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 309 {
        q.cents -= 309 / 2;
        q.flags |= 1 << 32;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 4 {
        q.cents = q.cents * 1001 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 56;
        q.flags |= 1 << 44;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 23063 {
        q.cents -= 54;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 48072 {
        q.cents -= 558;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 22185 {
        q.cents -= 104;
    }
}
