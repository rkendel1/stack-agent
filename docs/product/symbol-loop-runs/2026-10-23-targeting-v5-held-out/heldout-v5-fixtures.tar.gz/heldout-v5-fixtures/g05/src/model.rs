#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Order {
    pub sku_class: u8,
    pub qty: u32,
    pub region: u8,
    pub member: bool,
    pub weight_g: u32,
    /// Day of week, 0 = Monday.
    pub day: u8,
}

impl Order {
    pub fn new(sku_class: u8, qty: u32, region: u8) -> Self {
        Order { sku_class, qty, region, member: false, weight_g: 0, day: 0 }
    }

    pub fn member(mut self) -> Self {
        self.member = true;
        self
    }

    pub fn weight(mut self, grams: u32) -> Self {
        self.weight_g = grams;
        self
    }

    pub fn on_day(mut self, day: u8) -> Self {
        self.day = day % 7;
        self
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Quote {
    pub cents: i64,
    pub flags: u64,
    pub stages_run: u32,
}

impl Quote {
    pub fn dollars(&self) -> String {
        format!("{}.{:02}", self.cents / 100, self.cents % 100)
    }
}
