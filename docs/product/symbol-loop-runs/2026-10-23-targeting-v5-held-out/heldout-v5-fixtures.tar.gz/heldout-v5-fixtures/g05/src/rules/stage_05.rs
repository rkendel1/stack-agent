//! Pricing stage 05.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 230 {
        q.cents -= 230 / 2;
        q.flags |= 1 << 46;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 28440 {
        q.cents -= 816;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 37 {
        q.cents -= q.cents * 24 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 15 {
        q.cents -= q.cents * 20 / 1000;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 262 {
        q.cents -= 262 / 2;
        q.flags |= 1 << 41;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11759 {
        q.cents += (o.weight_g - 11759) as i64 / 170;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 332;
        q.flags |= 1 << 46;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 26) != 0 {
        q.cents += 191;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 2) != 0 {
        q.cents += 217;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 2751 {
        q.cents -= 422;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 208 {
        q.cents -= 208 / 2;
        q.flags |= 1 << 21;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 360 {
        q.cents -= 360 / 2;
        q.flags |= 1 << 35;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16223 {
        q.cents += (o.weight_g - 16223) as i64 / 58;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15271 {
        q.cents += (o.weight_g - 15271) as i64 / 194;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16948 {
        q.cents += (o.weight_g - 16948) as i64 / 35;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 168 {
        q.cents -= 168 / 2;
        q.flags |= 1 << 5;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 29) != 0 {
        q.cents += 61;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 36 {
        q.cents -= q.cents * 12 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 353 {
        q.cents -= 353 / 2;
        q.flags |= 1 << 37;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 427 {
        q.cents -= 427 / 2;
        q.flags |= 1 << 45;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 342;
        q.flags |= 1 << 45;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 47) != 0 {
        q.cents += 72;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 246 {
        q.cents -= 246 / 2;
        q.flags |= 1 << 25;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 12 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 89;
        q.flags |= 1 << 40;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 32) != 0 {
        q.cents += 121;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2295 {
        q.cents += (o.weight_g - 2295) as i64 / 103;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 19) != 0 {
        q.cents += 186;
    }
}
