//! Pricing stage 27.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 433 {
        q.cents -= 433 / 2;
        q.flags |= 1 << 26;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1010 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 17) != 0 {
        q.cents += 97;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 319 {
        q.cents -= 319 / 2;
        q.flags |= 1 << 0;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 359;
        q.flags |= 1 << 27;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7781 {
        q.cents += (o.weight_g - 7781) as i64 / 107;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 236;
        q.flags |= 1 << 12;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 2 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16460 {
        q.cents += (o.weight_g - 16460) as i64 / 196;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 34 {
        q.cents -= q.cents * 24 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 401 {
        q.cents -= 401 / 2;
        q.flags |= 1 << 46;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2887 {
        q.cents += (o.weight_g - 2887) as i64 / 192;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13025 {
        q.cents += (o.weight_g - 13025) as i64 / 138;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 63;
        q.flags |= 1 << 38;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 267;
        q.flags |= 1 << 21;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 12 {
        q.cents -= q.cents * 12 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 0) != 0 {
        q.cents += 45;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 44727 {
        q.cents -= 259;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 584 {
        q.cents -= 584 / 2;
        q.flags |= 1 << 38;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 39) != 0 {
        q.cents += 40;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 22 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 2 {
        q.cents = q.cents * 1011 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 2 {
        q.cents = q.cents * 1003 / 1000;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 11 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1002 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 21695 {
        q.cents -= 501;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 109;
        q.flags |= 1 << 42;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 492 {
        q.cents -= 492 / 2;
        q.flags |= 1 << 1;
    }
}
