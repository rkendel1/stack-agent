//! Pricing stage 15.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 329;
        q.flags |= 1 << 16;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1001 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19123 {
        q.cents += (o.weight_g - 19123) as i64 / 57;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 40723 {
        q.cents -= 136;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 4 {
        q.cents = q.cents * 1012 / 1000;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 1 {
        q.cents = q.cents * 1002 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 80 {
        q.cents -= 80 / 2;
        q.flags |= 1 << 6;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 8484 {
        q.cents -= 893;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 72;
        q.flags |= 1 << 34;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1008 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 362;
        q.flags |= 1 << 33;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 95;
        q.flags |= 1 << 11;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5158 {
        q.cents += (o.weight_g - 5158) as i64 / 48;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 29) != 0 {
        q.cents += 71;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9365 {
        q.cents += (o.weight_g - 9365) as i64 / 113;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 11198 {
        q.cents -= 112;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 300 {
        q.cents -= 300 / 2;
        q.flags |= 1 << 10;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 134 {
        q.cents -= 134 / 2;
        q.flags |= 1 << 20;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 19365 {
        q.cents -= 795;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 251 {
        q.cents -= 251 / 2;
        q.flags |= 1 << 8;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 38719 {
        q.cents -= 621;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 5164 {
        q.cents -= 487;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 15407 {
        q.cents -= 585;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 10 {
        q.cents -= q.cents * 24 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1011 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 4 {
        q.cents = q.cents * 1014 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9251 {
        q.cents += (o.weight_g - 9251) as i64 / 75;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 27936 {
        q.cents -= 889;
    }
}
