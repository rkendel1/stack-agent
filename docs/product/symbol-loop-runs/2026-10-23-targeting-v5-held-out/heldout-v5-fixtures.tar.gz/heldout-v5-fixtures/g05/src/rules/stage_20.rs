//! Pricing stage 20.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 325;
        q.flags |= 1 << 46;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 598 {
        q.cents -= 598 / 2;
        q.flags |= 1 << 22;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 4) != 0 {
        q.cents += 33;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 91 {
        q.cents -= 91 / 2;
        q.flags |= 1 << 9;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1011 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 32901 {
        q.cents -= 441;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1006 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1013 / 1000;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 37875 {
        q.cents -= 554;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 38) != 0 {
        q.cents += 165;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 186;
        q.flags |= 1 << 7;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 350;
        q.flags |= 1 << 7;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 282;
        q.flags |= 1 << 22;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 46) != 0 {
        q.cents += 203;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 16 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13225 {
        q.cents += (o.weight_g - 13225) as i64 / 196;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 253 {
        q.cents -= 253 / 2;
        q.flags |= 1 << 4;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 26) != 0 {
        q.cents += 135;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 584 {
        q.cents -= 584 / 2;
        q.flags |= 1 << 22;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 70;
        q.flags |= 1 << 25;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 27 {
        q.cents -= 27 / 2;
        q.flags |= 1 << 3;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 17) != 0 {
        q.cents += 244;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 25) != 0 {
        q.cents += 18;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2038 {
        q.cents += (o.weight_g - 2038) as i64 / 110;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 3 {
        q.cents = q.cents * 1013 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 32 {
        q.cents -= q.cents * 2 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5397 {
        q.cents += (o.weight_g - 5397) as i64 / 42;
    }
}
