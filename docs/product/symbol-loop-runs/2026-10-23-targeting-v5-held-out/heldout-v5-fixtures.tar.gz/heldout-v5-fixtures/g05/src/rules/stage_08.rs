//! Pricing stage 08.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 9 {
        q.cents -= q.cents * 7 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7668 {
        q.cents += (o.weight_g - 7668) as i64 / 169;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 4 {
        q.cents -= q.cents * 16 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 294;
        q.flags |= 1 << 40;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 38 {
        q.cents -= 38 / 2;
        q.flags |= 1 << 5;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 171;
        q.flags |= 1 << 10;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 52 {
        q.cents -= 52 / 2;
        q.flags |= 1 << 24;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10359 {
        q.cents += (o.weight_g - 10359) as i64 / 33;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 11) != 0 {
        q.cents += 104;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 5) != 0 {
        q.cents += 244;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 15) != 0 {
        q.cents += 115;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13578 {
        q.cents += (o.weight_g - 13578) as i64 / 50;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 19 {
        q.cents -= q.cents * 15 / 1000;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1007 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16366 {
        q.cents += (o.weight_g - 16366) as i64 / 91;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 97;
        q.flags |= 1 << 1;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 4123 {
        q.cents += (o.weight_g - 4123) as i64 / 123;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 38 {
        q.cents -= q.cents * 2 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 65;
        q.flags |= 1 << 29;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1013 / 1000;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 18558 {
        q.cents -= 361;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 44 {
        q.cents -= 44 / 2;
        q.flags |= 1 << 45;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 23) != 0 {
        q.cents += 137;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15163 {
        q.cents += (o.weight_g - 15163) as i64 / 73;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 313 {
        q.cents -= 313 / 2;
        q.flags |= 1 << 43;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1013 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 3439 {
        q.cents -= 485;
    }
}
