//! Pricing stage 24.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 5 {
        q.cents = q.cents * 1011 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 128 {
        q.cents -= 128 / 2;
        q.flags |= 1 << 14;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 5 {
        q.cents -= q.cents * 17 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 12 {
        q.cents -= q.cents * 9 / 1000;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 60;
        q.flags |= 1 << 43;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18908 {
        q.cents += (o.weight_g - 18908) as i64 / 166;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 233 {
        q.cents -= 233 / 2;
        q.flags |= 1 << 2;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 12963 {
        q.cents -= 404;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 13) != 0 {
        q.cents += 178;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 31) != 0 {
        q.cents += 82;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 14) != 0 {
        q.cents += 27;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 11) != 0 {
        q.cents += 123;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 143;
        q.flags |= 1 << 29;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 3) != 0 {
        q.cents += 166;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 27 {
        q.cents -= q.cents * 12 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 45) != 0 {
        q.cents += 20;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 0 {
        q.cents = q.cents * 1005 / 1000;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 3 {
        q.cents = q.cents * 1006 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19203 {
        q.cents += (o.weight_g - 19203) as i64 / 54;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 34 {
        q.cents -= q.cents * 23 / 1000;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1006 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 10 {
        q.cents -= q.cents * 16 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 133 {
        q.cents -= 133 / 2;
        q.flags |= 1 << 2;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 273;
        q.flags |= 1 << 10;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 40635 {
        q.cents -= 130;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7246 {
        q.cents += (o.weight_g - 7246) as i64 / 67;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 4 {
        q.cents = q.cents * 1010 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13317 {
        q.cents += (o.weight_g - 13317) as i64 / 199;
    }
}
