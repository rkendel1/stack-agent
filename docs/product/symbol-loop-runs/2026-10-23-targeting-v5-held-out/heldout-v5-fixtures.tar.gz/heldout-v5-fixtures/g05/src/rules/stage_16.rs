//! Pricing stage 16.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 33 {
        q.cents -= q.cents * 9 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 4015 {
        q.cents -= 771;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 13) != 0 {
        q.cents += 168;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 22 {
        q.cents -= q.cents * 6 / 1000;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 48451 {
        q.cents -= 431;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 17) != 0 {
        q.cents += 15;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 30) != 0 {
        q.cents += 196;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 7) != 0 {
        q.cents += 193;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 7 {
        q.cents -= q.cents * 14 / 1000;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1002 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10278 {
        q.cents += (o.weight_g - 10278) as i64 / 73;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 17875 {
        q.cents -= 794;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11320 {
        q.cents += (o.weight_g - 11320) as i64 / 62;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 356;
        q.flags |= 1 << 47;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 16) != 0 {
        q.cents += 76;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 10 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7950 {
        q.cents += (o.weight_g - 7950) as i64 / 120;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 4 {
        q.cents -= q.cents * 20 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 40187 {
        q.cents -= 506;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 16665 {
        q.cents -= 367;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 201 {
        q.cents -= 201 / 2;
        q.flags |= 1 << 9;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 597 {
        q.cents -= 597 / 2;
        q.flags |= 1 << 27;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 17743 {
        q.cents -= 160;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 20) != 0 {
        q.cents += 75;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 345;
        q.flags |= 1 << 21;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 1 {
        q.cents = q.cents * 1014 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 183;
        q.flags |= 1 << 44;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2756 {
        q.cents += (o.weight_g - 2756) as i64 / 184;
    }
}
