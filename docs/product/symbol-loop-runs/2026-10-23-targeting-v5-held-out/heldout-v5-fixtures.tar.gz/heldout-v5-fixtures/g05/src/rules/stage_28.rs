//! Pricing stage 28.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1007 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 37772 {
        q.cents -= 867;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 31 {
        q.cents -= q.cents * 24 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 476 {
        q.cents -= 476 / 2;
        q.flags |= 1 << 3;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 22148 {
        q.cents -= 625;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 23 {
        q.cents -= q.cents * 24 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 23 {
        q.cents -= q.cents * 21 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 145 {
        q.cents -= 145 / 2;
        q.flags |= 1 << 36;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 28 {
        q.cents -= q.cents * 18 / 1000;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7452 {
        q.cents += (o.weight_g - 7452) as i64 / 154;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 287;
        q.flags |= 1 << 45;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 177 {
        q.cents -= 177 / 2;
        q.flags |= 1 << 17;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 16703 {
        q.cents -= 635;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1013 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 36429 {
        q.cents -= 801;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 41) != 0 {
        q.cents += 233;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15014 {
        q.cents += (o.weight_g - 15014) as i64 / 142;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 8) != 0 {
        q.cents += 197;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 35) != 0 {
        q.cents += 45;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 232;
        q.flags |= 1 << 27;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 47) != 0 {
        q.cents += 192;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 2 {
        q.cents -= q.cents * 16 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 127 {
        q.cents -= 127 / 2;
        q.flags |= 1 << 40;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 2 {
        q.cents = q.cents * 1006 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 1923 {
        q.cents -= 75;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 48119 {
        q.cents -= 520;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 20) != 0 {
        q.cents += 207;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 133 {
        q.cents -= 133 / 2;
        q.flags |= 1 << 34;
    }
}
