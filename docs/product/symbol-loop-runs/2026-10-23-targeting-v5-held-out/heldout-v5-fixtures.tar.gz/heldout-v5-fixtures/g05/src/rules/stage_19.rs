//! Pricing stage 19.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 10 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 36 {
        q.cents -= q.cents * 13 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 555 {
        q.cents -= 555 / 2;
        q.flags |= 1 << 20;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 6861 {
        q.cents += (o.weight_g - 6861) as i64 / 29;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 26) != 0 {
        q.cents += 151;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 2706 {
        q.cents -= 632;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1008 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1010 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 288;
        q.flags |= 1 << 33;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9510 {
        q.cents += (o.weight_g - 9510) as i64 / 82;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1004 / 1000;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 12964 {
        q.cents += (o.weight_g - 12964) as i64 / 92;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 14 {
        q.cents -= q.cents * 4 / 1000;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 15 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 34) != 0 {
        q.cents += 93;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 5 {
        q.cents = q.cents * 1001 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 5 / 1000;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 264 {
        q.cents -= 264 / 2;
        q.flags |= 1 << 46;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 24) != 0 {
        q.cents += 137;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 8521 {
        q.cents -= 793;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 29) != 0 {
        q.cents += 11;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 35942 {
        q.cents -= 473;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 13) != 0 {
        q.cents += 113;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 1 {
        q.cents = q.cents * 1012 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2680 {
        q.cents += (o.weight_g - 2680) as i64 / 64;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 27176 {
        q.cents -= 284;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 49458 {
        q.cents -= 651;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 149;
        q.flags |= 1 << 38;
    }
}
