//! Pricing stage 04.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 324;
        q.flags |= 1 << 43;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 215;
        q.flags |= 1 << 9;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2976 {
        q.cents += (o.weight_g - 2976) as i64 / 35;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2488 {
        q.cents += (o.weight_g - 2488) as i64 / 142;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7230 {
        q.cents += (o.weight_g - 7230) as i64 / 118;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 14 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 9) != 0 {
        q.cents += 155;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 28190 {
        q.cents -= 580;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11729 {
        q.cents += (o.weight_g - 11729) as i64 / 51;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 42) != 0 {
        q.cents += 88;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 22 / 1000;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 27 {
        q.cents -= q.cents * 15 / 1000;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 520 {
        q.cents -= 520 / 2;
        q.flags |= 1 << 18;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 402 {
        q.cents -= 402 / 2;
        q.flags |= 1 << 27;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 331;
        q.flags |= 1 << 25;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 2 {
        q.cents = q.cents * 1010 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 21) != 0 {
        q.cents += 136;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 32) != 0 {
        q.cents += 157;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1005 / 1000;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 20) != 0 {
        q.cents += 199;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 13) != 0 {
        q.cents += 103;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 121;
        q.flags |= 1 << 11;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 764 {
        q.cents += (o.weight_g - 764) as i64 / 108;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 515 {
        q.cents -= 515 / 2;
        q.flags |= 1 << 2;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 136;
        q.flags |= 1 << 44;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 39) != 0 {
        q.cents += 203;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 394;
        q.flags |= 1 << 29;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 150;
        q.flags |= 1 << 13;
    }
}
