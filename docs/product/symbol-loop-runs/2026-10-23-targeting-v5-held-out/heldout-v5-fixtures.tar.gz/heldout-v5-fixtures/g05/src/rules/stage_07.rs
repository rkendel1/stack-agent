//! Pricing stage 07.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 42716 {
        q.cents -= 17;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 14) != 0 {
        q.cents += 109;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 103;
        q.flags |= 1 << 18;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 22) != 0 {
        q.cents += 47;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10661 {
        q.cents += (o.weight_g - 10661) as i64 / 123;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 12 {
        q.cents -= q.cents * 14 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 318;
        q.flags |= 1 << 22;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10127 {
        q.cents += (o.weight_g - 10127) as i64 / 141;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 290;
        q.flags |= 1 << 2;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 6084 {
        q.cents += (o.weight_g - 6084) as i64 / 197;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 187;
        q.flags |= 1 << 0;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 23) != 0 {
        q.cents += 121;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 65;
        q.flags |= 1 << 10;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 45) != 0 {
        q.cents += 33;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 56;
        q.flags |= 1 << 44;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 316;
        q.flags |= 1 << 40;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 5 {
        q.cents -= q.cents * 9 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 21851 {
        q.cents -= 12;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 27 {
        q.cents -= q.cents * 10 / 1000;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 12943 {
        q.cents += (o.weight_g - 12943) as i64 / 39;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 0) != 0 {
        q.cents += 205;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10157 {
        q.cents += (o.weight_g - 10157) as i64 / 190;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9759 {
        q.cents += (o.weight_g - 9759) as i64 / 101;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 30851 {
        q.cents -= 323;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 437 {
        q.cents -= 437 / 2;
        q.flags |= 1 << 23;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 44508 {
        q.cents -= 533;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19440 {
        q.cents += (o.weight_g - 19440) as i64 / 163;
    }
}
