//! The ordered list of pricing stages.

pub mod stage_00;
pub mod stage_01;
pub mod stage_02;
pub mod stage_03;
pub mod stage_04;
pub mod stage_05;
pub mod stage_06;
pub mod stage_07;
pub mod stage_08;
pub mod stage_09;
pub mod stage_10;
pub mod stage_11;
pub mod stage_12;
pub mod stage_13;
pub mod stage_14;
pub mod stage_15;
pub mod stage_16;
pub mod stage_17;
pub mod stage_18;
pub mod stage_19;
pub mod stage_20;
pub mod stage_21;
pub mod stage_22;
pub mod stage_23;
pub mod stage_24;
pub mod stage_25;
pub mod stage_26;
pub mod stage_27;
pub mod stage_28;
pub mod stage_29;

use crate::model::{Order, Quote};

pub fn run_all(q: &mut Quote, o: &Order) {
    stage_00::apply(q, o);
    stage_01::apply(q, o);
    stage_02::apply(q, o);
    stage_03::apply(q, o);
    stage_04::apply(q, o);
    stage_05::apply(q, o);
    stage_06::apply(q, o);
    stage_07::apply(q, o);
    stage_08::apply(q, o);
    stage_09::apply(q, o);
    stage_10::apply(q, o);
    stage_11::apply(q, o);
    stage_12::apply(q, o);
    stage_13::apply(q, o);
    stage_14::apply(q, o);
    stage_15::apply(q, o);
    stage_16::apply(q, o);
    stage_17::apply(q, o);
    stage_18::apply(q, o);
    stage_19::apply(q, o);
    stage_20::apply(q, o);
    stage_21::apply(q, o);
    stage_22::apply(q, o);
    stage_23::apply(q, o);
    stage_24::apply(q, o);
    stage_25::apply(q, o);
    stage_26::apply(q, o);
    stage_27::apply(q, o);
    stage_28::apply(q, o);
    stage_29::apply(q, o);
}
