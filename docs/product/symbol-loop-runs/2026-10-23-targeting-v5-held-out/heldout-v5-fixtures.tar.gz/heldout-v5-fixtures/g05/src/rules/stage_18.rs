//! Pricing stage 18.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 198;
        q.flags |= 1 << 43;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 9) != 0 {
        q.cents += 79;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 258;
        q.flags |= 1 << 13;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 6107 {
        q.cents -= 767;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 383;
        q.flags |= 1 << 22;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 20 {
        q.cents -= q.cents * 14 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9199 {
        q.cents += (o.weight_g - 9199) as i64 / 180;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 38490 {
        q.cents -= 865;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11037 {
        q.cents += (o.weight_g - 11037) as i64 / 87;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 2 {
        q.cents = q.cents * 1001 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 13093 {
        q.cents -= 631;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19773 {
        q.cents += (o.weight_g - 19773) as i64 / 176;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 8335 {
        q.cents -= 214;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 544 {
        q.cents -= 544 / 2;
        q.flags |= 1 << 17;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 27 {
        q.cents -= 27 / 2;
        q.flags |= 1 << 2;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 319;
        q.flags |= 1 << 46;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 9 && q.cents > 174 {
        q.cents -= 174 / 2;
        q.flags |= 1 << 11;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 343 {
        q.cents -= 343 / 2;
        q.flags |= 1 << 12;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 164;
        q.flags |= 1 << 24;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7846 {
        q.cents -= 585;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 10 {
        q.cents -= q.cents * 7 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1010 / 1000;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 3470 {
        q.cents += (o.weight_g - 3470) as i64 / 23;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 12 {
        q.cents -= q.cents * 4 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 369 {
        q.cents -= 369 / 2;
        q.flags |= 1 << 24;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 39098 {
        q.cents -= 153;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 35655 {
        q.cents -= 851;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 243;
        q.flags |= 1 << 18;
    }
}
