//! Pricing stage 23.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 444 {
        q.cents -= 444 / 2;
        q.flags |= 1 << 13;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 6;
        q.flags |= 1 << 10;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 19) != 0 {
        q.cents += 152;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 185 {
        q.cents -= 185 / 2;
        q.flags |= 1 << 37;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 19351 {
        q.cents += (o.weight_g - 19351) as i64 / 87;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 277;
        q.flags |= 1 << 9;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 17346 {
        q.cents += (o.weight_g - 17346) as i64 / 157;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1004 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 4882 {
        q.cents += (o.weight_g - 4882) as i64 / 77;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 39 {
        q.cents -= q.cents * 3 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 11 {
        q.cents -= q.cents * 10 / 1000;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 552 {
        q.cents -= 552 / 2;
        q.flags |= 1 << 45;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 37198 {
        q.cents -= 606;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 38) != 0 {
        q.cents += 219;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 34) != 0 {
        q.cents += 28;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 19652 {
        q.cents -= 469;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 22 {
        q.cents -= q.cents * 6 / 1000;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1013 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 12021 {
        q.cents += (o.weight_g - 12021) as i64 / 86;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 34373 {
        q.cents -= 193;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 387;
        q.flags |= 1 << 26;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15861 {
        q.cents += (o.weight_g - 15861) as i64 / 192;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 32;
        q.flags |= 1 << 38;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 14252 {
        q.cents -= 480;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 10335 {
        q.cents -= 535;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 8196 {
        q.cents += (o.weight_g - 8196) as i64 / 93;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 333;
        q.flags |= 1 << 32;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 16 {
        q.cents -= q.cents * 6 / 1000;
    }
}
