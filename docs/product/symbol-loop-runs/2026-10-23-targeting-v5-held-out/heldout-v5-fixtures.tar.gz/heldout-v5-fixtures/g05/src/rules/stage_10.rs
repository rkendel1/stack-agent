//! Pricing stage 10.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 7380 {
        q.cents += (o.weight_g - 7380) as i64 / 62;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 29 {
        q.cents -= q.cents * 8 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 351;
        q.flags |= 1 << 47;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 18413 {
        q.cents += (o.weight_g - 18413) as i64 / 108;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 17114 {
        q.cents += (o.weight_g - 17114) as i64 / 49;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2353 {
        q.cents += (o.weight_g - 2353) as i64 / 96;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 43077 {
        q.cents -= 435;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 39 {
        q.cents -= q.cents * 14 / 1000;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 2513 {
        q.cents -= 246;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 11) != 0 {
        q.cents += 236;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 4 {
        q.cents -= q.cents * 23 / 1000;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 76;
        q.flags |= 1 << 7;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 24 {
        q.cents -= q.cents * 21 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 28 {
        q.cents -= q.cents * 23 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 4) != 0 {
        q.cents += 29;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 143;
        q.flags |= 1 << 8;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5689 {
        q.cents += (o.weight_g - 5689) as i64 / 180;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 34524 {
        q.cents -= 391;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9989 {
        q.cents += (o.weight_g - 9989) as i64 / 20;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10561 {
        q.cents += (o.weight_g - 10561) as i64 / 56;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 14442 {
        q.cents += (o.weight_g - 14442) as i64 / 80;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13442 {
        q.cents += (o.weight_g - 13442) as i64 / 99;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 45) != 0 {
        q.cents += 142;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 5979 {
        q.cents -= 634;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 8 && q.cents > 438 {
        q.cents -= 438 / 2;
        q.flags |= 1 << 28;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 207;
        q.flags |= 1 << 31;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1007 / 1000;
    }
}
