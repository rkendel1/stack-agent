//! Pricing stage 29.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 313 {
        q.cents -= 313 / 2;
        q.flags |= 1 << 15;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 268;
        q.flags |= 1 << 17;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 42864 {
        q.cents -= 411;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 48362 {
        q.cents -= 684;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 320 {
        q.cents -= 320 / 2;
        q.flags |= 1 << 44;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 85;
        q.flags |= 1 << 42;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 377;
        q.flags |= 1 << 29;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1008 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 46) != 0 {
        q.cents += 86;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1011 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 5497 {
        q.cents -= 255;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 33762 {
        q.cents -= 279;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 0 {
        q.cents = q.cents * 1002 / 1000;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 316 {
        q.cents -= 316 / 2;
        q.flags |= 1 << 26;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 99;
        q.flags |= 1 << 22;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9735 {
        q.cents += (o.weight_g - 9735) as i64 / 80;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 32483 {
        q.cents -= 635;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 17448 {
        q.cents -= 507;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 357 {
        q.cents -= 357 / 2;
        q.flags |= 1 << 16;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1012 / 1000;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 0 {
        q.cents = q.cents * 1011 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7731 {
        q.cents -= 264;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 589 {
        q.cents -= 589 / 2;
        q.flags |= 1 << 29;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 1) != 0 {
        q.cents += 234;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 1 {
        q.cents = q.cents * 1013 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13767 {
        q.cents += (o.weight_g - 13767) as i64 / 168;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 23) != 0 {
        q.cents += 214;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 330 {
        q.cents -= 330 / 2;
        q.flags |= 1 << 22;
    }
}
