//! Pricing stage 13.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 11) != 0 {
        q.cents += 211;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 10 {
        q.cents -= q.cents * 12 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 347 {
        q.cents -= 347 / 2;
        q.flags |= 1 << 20;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 9422 {
        q.cents -= 425;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11730 {
        q.cents += (o.weight_g - 11730) as i64 / 108;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 1815 {
        q.cents += (o.weight_g - 1815) as i64 / 161;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1013 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1014 / 1000;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 49434 {
        q.cents -= 781;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 2 {
        q.cents -= q.cents * 19 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1006 / 1000;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 348;
        q.flags |= 1 << 29;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 30) != 0 {
        q.cents += 58;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 31) != 0 {
        q.cents += 136;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 33 {
        q.cents -= q.cents * 2 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 39) != 0 {
        q.cents += 158;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 2) != 0 {
        q.cents += 108;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2011 {
        q.cents += (o.weight_g - 2011) as i64 / 73;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 40) != 0 {
        q.cents += 152;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 35622 {
        q.cents -= 540;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 0 {
        q.cents = q.cents * 1001 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 23348 {
        q.cents -= 797;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 24) != 0 {
        q.cents += 76;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 15 {
        q.cents -= q.cents * 3 / 1000;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 24 {
        q.cents -= q.cents * 16 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 40137 {
        q.cents -= 78;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2794 {
        q.cents += (o.weight_g - 2794) as i64 / 145;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 31) != 0 {
        q.cents += 13;
    }
}
