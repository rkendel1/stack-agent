//! Pricing stage 03.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 7 && q.cents > 216 {
        q.cents -= 216 / 2;
        q.flags |= 1 << 6;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 3 {
        q.cents -= q.cents * 4 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 3 {
        q.cents = q.cents * 1013 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 14 {
        q.cents -= q.cents * 16 / 1000;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 17131 {
        q.cents -= 645;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 8171 {
        q.cents += (o.weight_g - 8171) as i64 / 84;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 32 {
        q.cents -= 32 / 2;
        q.flags |= 1 << 36;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 7 {
        q.cents += 101;
        q.flags |= 1 << 17;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 26987 {
        q.cents -= 779;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 30954 {
        q.cents -= 490;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 45649 {
        q.cents -= 730;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 15571 {
        q.cents += (o.weight_g - 15571) as i64 / 167;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 363;
        q.flags |= 1 << 22;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1005 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 77;
        q.flags |= 1 << 13;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 48461 {
        q.cents -= 543;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 2 {
        q.cents = q.cents * 1002 / 1000;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1007 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 212;
        q.flags |= 1 << 4;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 43358 {
        q.cents -= 737;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 8) != 0 {
        q.cents += 105;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7498 {
        q.cents -= 845;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 35 {
        q.cents -= q.cents * 16 / 1000;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 14525 {
        q.cents += (o.weight_g - 14525) as i64 / 93;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 269;
        q.flags |= 1 << 11;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 4419 {
        q.cents -= 342;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 1 {
        q.cents = q.cents * 1007 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 26143 {
        q.cents -= 776;
    }
}
