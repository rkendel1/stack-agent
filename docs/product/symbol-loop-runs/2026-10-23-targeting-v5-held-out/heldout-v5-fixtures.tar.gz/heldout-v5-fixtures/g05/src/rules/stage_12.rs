//! Pricing stage 12.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 17666 {
        q.cents += (o.weight_g - 17666) as i64 / 177;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 16516 {
        q.cents += (o.weight_g - 16516) as i64 / 30;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 345;
        q.flags |= 1 << 16;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 531 {
        q.cents -= 531 / 2;
        q.flags |= 1 << 5;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 228;
        q.flags |= 1 << 36;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 2 {
        q.cents = q.cents * 1012 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 15 {
        q.cents -= q.cents * 2 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 4870 {
        q.cents += (o.weight_g - 4870) as i64 / 118;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 47) != 0 {
        q.cents += 202;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 41) != 0 {
        q.cents += 31;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 282 {
        q.cents -= 282 / 2;
        q.flags |= 1 << 20;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 1 {
        q.cents = q.cents * 1005 / 1000;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 22) != 0 {
        q.cents += 133;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 56;
        q.flags |= 1 << 32;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 2 {
        q.cents -= q.cents * 22 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1014 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 159;
        q.flags |= 1 << 39;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 38822 {
        q.cents -= 717;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 12) != 0 {
        q.cents += 63;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 15998 {
        q.cents -= 106;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 4 && q.cents > 109 {
        q.cents -= 109 / 2;
        q.flags |= 1 << 15;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 42692 {
        q.cents -= 852;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 5 == 3 {
        q.cents = q.cents * 1004 / 1000;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 370;
        q.flags |= 1 << 1;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 27 {
        q.cents -= q.cents * 12 / 1000;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 24 {
        q.cents -= q.cents * 14 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 21273 {
        q.cents -= 66;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1011 / 1000;
    }
}
