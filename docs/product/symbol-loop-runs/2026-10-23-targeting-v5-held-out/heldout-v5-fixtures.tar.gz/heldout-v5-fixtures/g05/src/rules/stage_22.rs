//! Pricing stage 22.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 3 {
        q.cents = q.cents * 1008 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 352 {
        q.cents -= 352 / 2;
        q.flags |= 1 << 5;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 0 {
        q.cents = q.cents * 1001 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 1960 {
        q.cents += (o.weight_g - 1960) as i64 / 57;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 6 {
        q.cents -= q.cents * 19 / 1000;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 10 / 1000;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 11611 {
        q.cents += (o.weight_g - 11611) as i64 / 35;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 1557 {
        q.cents += (o.weight_g - 1557) as i64 / 61;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 37857 {
        q.cents -= 541;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 20287 {
        q.cents -= 254;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 3303 {
        q.cents += (o.weight_g - 3303) as i64 / 94;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 6129 {
        q.cents += (o.weight_g - 6129) as i64 / 116;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 7907 {
        q.cents -= 208;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 32486 {
        q.cents -= 727;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 18) != 0 {
        q.cents += 177;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 14139 {
        q.cents -= 305;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 2 {
        q.cents += 290;
        q.flags |= 1 << 33;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 29871 {
        q.cents -= 720;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 297;
        q.flags |= 1 << 14;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 15833 {
        q.cents -= 207;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 594 {
        q.cents -= 594 / 2;
        q.flags |= 1 << 43;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 28386 {
        q.cents -= 877;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 9) != 0 {
        q.cents += 77;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 221;
        q.flags |= 1 << 19;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 8135 {
        q.cents += (o.weight_g - 8135) as i64 / 35;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 2 {
        q.cents = q.cents * 1007 / 1000;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 20 {
        q.cents -= q.cents * 16 / 1000;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 316 {
        q.cents -= 316 / 2;
        q.flags |= 1 << 16;
    }
}
