//! Pricing stage 11.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13834 {
        q.cents += (o.weight_g - 13834) as i64 / 95;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 31 {
        q.cents -= q.cents * 14 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 39 {
        q.cents -= q.cents * 6 / 1000;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 0 {
        q.cents += 232;
        q.flags |= 1 << 17;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 87 {
        q.cents -= 87 / 2;
        q.flags |= 1 << 46;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 9527 {
        q.cents += (o.weight_g - 9527) as i64 / 78;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 7) != 0 {
        q.cents += 76;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 173;
        q.flags |= 1 << 42;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 46892 {
        q.cents -= 437;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 8 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 16247 {
        q.cents -= 364;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 157 {
        q.cents -= 157 / 2;
        q.flags |= 1 << 46;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1006 / 1000;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1013 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 27 {
        q.cents -= q.cents * 4 / 1000;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 1) != 0 {
        q.cents += 9;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 36) != 0 {
        q.cents += 15;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 24) != 0 {
        q.cents += 103;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 16 {
        q.cents -= q.cents * 10 / 1000;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 1 && q.cents > 526 {
        q.cents -= 526 / 2;
        q.flags |= 1 << 9;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1001 / 1000;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 14289 {
        q.cents += (o.weight_g - 14289) as i64 / 68;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 13058 {
        q.cents += (o.weight_g - 13058) as i64 / 77;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 1983 {
        q.cents += (o.weight_g - 1983) as i64 / 163;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 31) != 0 {
        q.cents += 77;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 318 {
        q.cents -= 318 / 2;
        q.flags |= 1 << 34;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 0 && q.cents > 315 {
        q.cents -= 315 / 2;
        q.flags |= 1 << 14;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 15) != 0 {
        q.cents += 125;
    }
}
