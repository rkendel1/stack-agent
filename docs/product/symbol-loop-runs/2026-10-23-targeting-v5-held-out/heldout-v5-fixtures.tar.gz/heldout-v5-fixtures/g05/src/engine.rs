use crate::model::{Order, Quote};
use crate::rules;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Breakdown {
    pub base: i64,
    pub quote: Quote,
}

fn class_rate(sku_class: u8) -> i64 {
    match sku_class {
        0 => 199,
        1 => 349,
        2 => 525,
        3 => 780,
        4 => 1_150,
        5 => 1_675,
        6 => 2_400,
        7 => 3_300,
        8 => 4_900,
        _ => 7_250,
    }
}

pub fn base_price(o: &Order) -> i64 {
    let goods = class_rate(o.sku_class) * o.qty as i64;
    let freight = 450 + o.weight_g as i64 / 25;
    goods + freight
}

fn finalize(q: &mut Quote) {
    if q.cents < 0 {
        q.cents = 0;
    }
    // round to the nearest 5 cents
    q.cents = (q.cents + 2) / 5 * 5;
}

pub fn evaluate(o: &Order) -> Breakdown {
    let base = base_price(o);
    let mut q = Quote { cents: base, flags: 0, stages_run: 0 };
    rules::run_all(&mut q, o);
    finalize(&mut q);
    Breakdown { base, quote: q }
}
