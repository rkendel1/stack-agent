//! Pricing stage 06.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 27797 {
        q.cents -= 585;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 39 {
        q.cents -= q.cents * 8 / 1000;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 187;
        q.flags |= 1 << 6;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 2 == 0 {
        q.cents = q.cents * 1012 / 1000;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 12425 {
        q.cents += (o.weight_g - 12425) as i64 / 31;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 3 {
        q.cents += 352;
        q.flags |= 1 << 40;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 229 {
        q.cents -= 229 / 2;
        q.flags |= 1 << 14;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 592 {
        q.cents -= 592 / 2;
        q.flags |= 1 << 4;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 47) != 0 {
        q.cents += 141;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 36) != 0 {
        q.cents += 189;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 26 {
        q.cents -= q.cents * 10 / 1000;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 6 && q.cents > 401 {
        q.cents -= 401 / 2;
        q.flags |= 1 << 43;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 331;
        q.flags |= 1 << 12;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 35 {
        q.cents -= q.cents * 1 / 1000;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5584 {
        q.cents += (o.weight_g - 5584) as i64 / 103;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 23406 {
        q.cents -= 338;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 6921 {
        q.cents += (o.weight_g - 6921) as i64 / 68;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 5 {
        q.cents = q.cents * 1001 / 1000;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 100;
        q.flags |= 1 << 16;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 9 {
        q.cents += 249;
        q.flags |= 1 << 16;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 44) != 0 {
        q.cents += 60;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 33) != 0 {
        q.cents += 205;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 4 {
        q.cents -= q.cents * 12 / 1000;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 41) != 0 {
        q.cents += 183;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 88 {
        q.cents -= 88 / 2;
        q.flags |= 1 << 28;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 3 && q.cents > 123 {
        q.cents -= 123 / 2;
        q.flags |= 1 << 32;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 43) != 0 {
        q.cents += 9;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 4 == 1 {
        q.cents = q.cents * 1013 / 1000;
    }
}
