//! Pricing stage 25.

#![allow(unused_variables)]

use crate::model::{Order, Quote};

pub fn apply(q: &mut Quote, o: &Order) {
    q.stages_run += 1;
    r00(q, o);
}

fn r00(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 0 {
        q.cents = q.cents * 1003 / 1000;
    }
    r01(q, o);
}

fn r01(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 20043 {
        q.cents -= 336;
    }
    r02(q, o);
}

fn r02(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 45602 {
        q.cents -= 556;
    }
    r03(q, o);
}

fn r03(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 16854 {
        q.cents -= 502;
    }
    r04(q, o);
}

fn r04(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 5387 {
        q.cents += (o.weight_g - 5387) as i64 / 152;
    }
    r05(q, o);
}

fn r05(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 1 {
        q.cents += 398;
        q.flags |= 1 << 1;
    }
    r06(q, o);
}

fn r06(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 3 == 2 {
        q.cents = q.cents * 1006 / 1000;
    }
    r07(q, o);
}

fn r07(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 5 && q.cents > 514 {
        q.cents -= 514 / 2;
        q.flags |= 1 << 6;
    }
    r08(q, o);
}

fn r08(q: &mut Quote, o: &Order) {
    // volume discount
    if o.qty >= 5 {
        q.cents -= q.cents * 6 / 1000;
    }
    r09(q, o);
}

fn r09(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 3 {
        q.cents = q.cents * 1014 / 1000;
    }
    r10(q, o);
}

fn r10(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 6 {
        q.cents += 374;
        q.flags |= 1 << 7;
    }
    r11(q, o);
}

fn r11(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 25;
        q.flags |= 1 << 24;
    }
    r12(q, o);
}

fn r12(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10570 {
        q.cents += (o.weight_g - 10570) as i64 / 72;
    }
    r13(q, o);
}

fn r13(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 1883 {
        q.cents += (o.weight_g - 1883) as i64 / 185;
    }
    r14(q, o);
}

fn r14(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 5 {
        q.cents += 383;
        q.flags |= 1 << 31;
    }
    r15(q, o);
}

fn r15(q: &mut Quote, o: &Order) {
    // weekday adjustment
    if o.day % 6 == 1 {
        q.cents = q.cents * 1008 / 1000;
    }
    r16(q, o);
}

fn r16(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 28) != 0 {
        q.cents += 234;
    }
    r17(q, o);
}

fn r17(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 10872 {
        q.cents += (o.weight_g - 10872) as i64 / 98;
    }
    r18(q, o);
}

fn r18(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 8617 {
        q.cents += (o.weight_g - 8617) as i64 / 95;
    }
    r19(q, o);
}

fn r19(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 4 {
        q.cents += 101;
        q.flags |= 1 << 7;
    }
    r20(q, o);
}

fn r20(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 26) != 0 {
        q.cents += 7;
    }
    r21(q, o);
}

fn r21(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 33) != 0 {
        q.cents += 62;
    }
    r22(q, o);
}

fn r22(q: &mut Quote, o: &Order) {
    // regional handling fee
    if o.region == 8 {
        q.cents += 157;
        q.flags |= 1 << 15;
    }
    r23(q, o);
}

fn r23(q: &mut Quote, o: &Order) {
    // follow-on charge for an earlier flag
    if q.flags & (1 << 40) != 0 {
        q.cents += 242;
    }
    r24(q, o);
}

fn r24(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 2157 {
        q.cents += (o.weight_g - 2157) as i64 / 27;
    }
    r25(q, o);
}

fn r25(q: &mut Quote, o: &Order) {
    // member credit above threshold
    if o.member && q.cents > 19404 {
        q.cents -= 95;
    }
    r26(q, o);
}

fn r26(q: &mut Quote, o: &Order) {
    // heavy parcel surcharge
    if o.weight_g > 784 {
        q.cents += (o.weight_g - 784) as i64 / 112;
    }
    r27(q, o);
}

fn r27(q: &mut Quote, o: &Order) {
    // product class promotion
    if o.sku_class == 2 && q.cents > 438 {
        q.cents -= 438 / 2;
        q.flags |= 1 << 7;
    }
}
