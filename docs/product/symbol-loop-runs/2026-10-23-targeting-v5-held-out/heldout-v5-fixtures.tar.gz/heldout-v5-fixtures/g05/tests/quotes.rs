use quoteflow::{base_price, evaluate, price, price_all, Order};

fn standard_order() -> Order {
    Order::new(3, 5, 2).weight(1200).on_day(1)
}

fn regional_bulk_order() -> Order {
    Order::new(5, 20, 7).member().weight(8000).on_day(3)
}

#[test]
fn base_price_is_goods_plus_freight() {
    assert_eq!(base_price(&standard_order()), 5 * 780 + 450 + 1200 / 25);
}

#[test]
fn every_stage_runs() {
    let b = evaluate(&standard_order());
    assert_eq!(b.quote.stages_run, 30);
    assert_eq!(b.base, 4398);
}

#[test]
fn standard_order_quote() {
    let q = price(&standard_order());
    assert_eq!(q.cents, 8295);
    assert_eq!(q.dollars(), "82.95");
}

#[test]
fn regional_bulk_order_quote() {
    let q = price(&regional_bulk_order());
    assert_eq!(q.cents, 9505);
}

#[test]
fn small_regional_bulk_order_quote() {
    let q = price(&Order::new(1, 12, 7));
    assert_eq!(q.dollars(), "75.00");
}

#[test]
fn regional_order_below_bulk_threshold() {
    assert_eq!(price(&Order::new(6, 11, 7).on_day(6)).cents, 27100);
    assert_eq!(price(&Order::new(9, 2, 7).member()).cents, 8525);
}

#[test]
fn heavy_bulk_order_elsewhere() {
    let q = price(&Order::new(0, 100, 4).weight(30000).on_day(5));
    assert_eq!(q.cents, 30465);
}

#[test]
fn quotes_are_rounded_to_five_cents_and_keep_order() {
    let orders = [standard_order(), Order::new(0, 100, 4).weight(30000).on_day(5), Order::new(9, 2, 7).member()];
    let qs = price_all(&orders);
    assert_eq!(qs.iter().map(|q| q.cents).collect::<Vec<_>>(), vec![8295, 30465, 8525]);
    assert!(qs.iter().all(|q| q.cents % 5 == 0 && q.cents >= 0));
}
