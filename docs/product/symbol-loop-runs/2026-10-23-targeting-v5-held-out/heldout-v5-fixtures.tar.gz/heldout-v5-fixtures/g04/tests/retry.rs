use std::time::Duration;

use jobretry::{parse_backoff, parse_policy, run_with_retry, AttemptError, Backoff, Jitter, Outcome, RecordingSleeper, RetryPolicy};

fn ms(v: &[u64]) -> Vec<Duration> {
    v.iter().map(|m| Duration::from_millis(*m)).collect()
}

#[test]
fn fixed_schedule() {
    let p = RetryPolicy::new(4, Backoff::Fixed { delay_ms: 250 });
    assert_eq!(p.schedule(), ms(&[250, 250, 250]));
}

#[test]
fn linear_schedule_from_spec() {
    let p = parse_policy("attempts=4; backoff=linear:100:50").unwrap();
    assert_eq!(p.schedule(), ms(&[100, 150, 200]));
}

#[test]
fn exponential_delays_are_capped() {
    let p = RetryPolicy::new(6, Backoff::Exponential { base_ms: 100, factor: 2, max_ms: 1000 });
    assert_eq!(p.schedule(), ms(&[100, 200, 400, 800, 1000]));
}

#[test]
fn capped_exponential_from_spec() {
    let p = parse_policy("attempts=7;backoff=exp:50:3:2000").unwrap();
    assert_eq!(p.schedule(), ms(&[50, 150, 450, 1350, 2000, 2000]));
    assert_eq!(p.total_wait(), Duration::from_millis(6000));
}

#[test]
fn uncapped_exponential_spec_still_parses() {
    let b = parse_backoff("exp:10:2").unwrap();
    assert_eq!(b.delay_for(1), Duration::from_millis(10));
    assert_eq!(b.delay_for(11), Duration::from_millis(10_240));
}

#[test]
fn jitter_alternates_around_nominal() {
    let p = RetryPolicy::new(4, Backoff::Fixed { delay_ms: 1000 }).with_jitter(Jitter::Spread(10));
    assert_eq!(p.schedule(), ms(&[900, 1100, 900]));
}

#[test]
fn bad_specs_are_rejected() {
    assert!(parse_policy("attempts=0").is_err());
    assert!(parse_policy("backoff=exp:100:1").is_err());
    assert!(parse_policy("retries=3").is_err());
    assert!(parse_backoff("fixed").is_err());
}

#[test]
fn runner_gives_up_after_policy_is_exhausted() {
    let p = parse_policy("attempts=3;backoff=fixed:5").unwrap();
    let mut sleeper = RecordingSleeper::default();
    let out: Outcome<()> = run_with_retry(&p, &mut sleeper, |_| Err(AttemptError::transient("busy")));
    assert_eq!(out, Outcome::GaveUp { last_error: AttemptError::transient("busy"), attempts: 3 });
    assert_eq!(sleeper.slept, ms(&[5, 5]));
}

#[test]
fn runner_waits_capped_delays() {
    let p = parse_policy("attempts=5;backoff=exp:400:2:1000").unwrap();
    let mut sleeper = RecordingSleeper::default();
    let out = run_with_retry(&p, &mut sleeper, |n| if n < 5 { Err(AttemptError::transient("x")) } else { Ok(n * 10) });
    assert_eq!(out, Outcome::Succeeded { value: 50, attempts: 5 });
    assert_eq!(sleeper.slept, ms(&[400, 800, 1000, 1000]));
}

#[test]
fn runner_stops_on_fatal_error() {
    let p = RetryPolicy::default();
    let mut sleeper = RecordingSleeper::default();
    let out: Outcome<u8> = run_with_retry(&p, &mut sleeper, |_| Err(AttemptError::fatal("bad request")));
    assert!(matches!(out, Outcome::Aborted { attempts: 1, .. }));
    assert!(sleeper.slept.is_empty());
}
