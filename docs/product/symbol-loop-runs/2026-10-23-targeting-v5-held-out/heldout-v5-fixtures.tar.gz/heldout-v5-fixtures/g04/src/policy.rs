use std::time::Duration;

use crate::backoff::Backoff;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Jitter {
    None,
    /// Deterministic +/- percentage spread based on the attempt number, so
    /// that a fleet of workers does not retry in lockstep but tests stay
    /// reproducible.
    Spread(u8),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetryPolicy {
    pub max_attempts: u32,
    pub backoff: Backoff,
    pub jitter: Jitter,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        RetryPolicy { max_attempts: 3, backoff: Backoff::Fixed { delay_ms: 1000 }, jitter: Jitter::None }
    }
}

fn apply_jitter(d: Duration, jitter: Jitter, attempt: u32) -> Duration {
    match jitter {
        Jitter::None => d,
        Jitter::Spread(pct) => {
            let pct = pct.min(100) as i64;
            // alternate below/above the nominal delay
            let sign = if attempt % 2 == 0 { 1 } else { -1 };
            let ms = d.as_millis() as i64;
            let delta = ms * pct / 100 * sign;
            Duration::from_millis((ms + delta).max(0) as u64)
        }
    }
}

impl RetryPolicy {
    pub fn new(max_attempts: u32, backoff: Backoff) -> Self {
        RetryPolicy { max_attempts, backoff, jitter: Jitter::None }
    }

    pub fn with_jitter(mut self, jitter: Jitter) -> Self {
        self.jitter = jitter;
        self
    }

    /// Delay before retry `retry` (1-based), or `None` when the policy is exhausted.
    pub fn delay_before(&self, retry: u32) -> Option<Duration> {
        if retry == 0 || retry >= self.max_attempts {
            return None;
        }
        Some(apply_jitter(self.backoff.delay_for(retry), self.jitter, retry))
    }

    /// All delays the policy would wait, in order.
    pub fn schedule(&self) -> Vec<Duration> {
        (1..self.max_attempts).filter_map(|r| self.delay_before(r)).collect()
    }

    pub fn total_wait(&self) -> Duration {
        self.schedule().into_iter().sum()
    }

    pub fn summary(&self) -> String {
        format!("{} attempts, {}", self.max_attempts, self.backoff.describe())
    }
}
