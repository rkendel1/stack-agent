use std::time::Duration;

/// How long to wait before retry number `attempt` (1 = first retry).
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Backoff {
    /// Always wait the same amount.
    Fixed { delay_ms: u64 },
    /// `start_ms`, then `start_ms + step_ms`, `start_ms + 2*step_ms`, ...
    Linear { start_ms: u64, step_ms: u64 },
    /// `base_ms * factor^(attempt-1)`.
    Exponential { base_ms: u64, factor: u32 },
}

impl Backoff {
    pub fn none() -> Backoff {
        Backoff::Fixed { delay_ms: 0 }
    }

    pub fn delay_for(&self, attempt: u32) -> Duration {
        let n = attempt.max(1) - 1;
        let ms = match self {
            Backoff::Fixed { delay_ms } => *delay_ms,
            Backoff::Linear { start_ms, step_ms } => start_ms.saturating_add(step_ms.saturating_mul(n as u64)),
            Backoff::Exponential { base_ms, factor } => {
                base_ms.saturating_mul((*factor as u64).saturating_pow(n))
            }
        };
        Duration::from_millis(ms)
    }

    pub fn describe(&self) -> String {
        match self {
            Backoff::Fixed { delay_ms } => format!("fixed {delay_ms}ms"),
            Backoff::Linear { start_ms, step_ms } => format!("linear {start_ms}ms +{step_ms}ms"),
            Backoff::Exponential { base_ms, factor, .. } => format!("exponential {base_ms}ms x{factor}"),
        }
    }
}
