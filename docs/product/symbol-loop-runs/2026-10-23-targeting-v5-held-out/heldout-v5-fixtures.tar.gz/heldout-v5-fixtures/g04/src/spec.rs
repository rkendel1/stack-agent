use std::fmt;

use crate::backoff::Backoff;
use crate::policy::{Jitter, RetryPolicy};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SpecError(pub String);

impl fmt::Display for SpecError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid retry spec: {}", self.0)
    }
}

impl std::error::Error for SpecError {}

fn num(s: &str, what: &str) -> Result<u64, SpecError> {
    s.trim().parse().map_err(|_| SpecError(format!("{what} must be a number, got '{s}'")))
}

/// Parses `fixed:500`, `linear:100:50` or `exp:100:2`.
pub fn parse_backoff(s: &str) -> Result<Backoff, SpecError> {
    let mut parts = s.trim().split(':');
    let kind = parts.next().unwrap_or("");
    let args: Vec<&str> = parts.collect();
    match kind {
        "fixed" => match args.as_slice() {
            [d] => Ok(Backoff::Fixed { delay_ms: num(d, "delay")? }),
            _ => Err(SpecError("fixed takes one argument".into())),
        },
        "linear" => match args.as_slice() {
            [a, b] => Ok(Backoff::Linear { start_ms: num(a, "start")?, step_ms: num(b, "step")? }),
            _ => Err(SpecError("linear takes two arguments".into())),
        },
        "exp" | "exponential" => match args.as_slice() {
            [base, factor] => {
                let factor = num(factor, "factor")?;
                if factor < 2 || factor > u32::MAX as u64 {
                    return Err(SpecError(format!("factor {factor} out of range")));
                }
                Ok(Backoff::Exponential { base_ms: num(base, "base")?, factor: factor as u32 })
            }
            _ => Err(SpecError("exp takes two arguments".into())),
        },
        "none" if args.is_empty() => Ok(Backoff::none()),
        other => Err(SpecError(format!("unknown backoff '{other}'"))),
    }
}

/// Parses `attempts=5;backoff=exp:100:2;jitter=10`. Every key is optional.
pub fn parse_policy(s: &str) -> Result<RetryPolicy, SpecError> {
    let mut policy = RetryPolicy::default();
    for item in s.split(';').map(str::trim).filter(|i| !i.is_empty()) {
        let (key, value) = item
            .split_once('=')
            .ok_or_else(|| SpecError(format!("expected key=value, got '{item}'")))?;
        match key.trim() {
            "attempts" => {
                let n = num(value, "attempts")?;
                if n == 0 {
                    return Err(SpecError("attempts must be at least 1".into()));
                }
                policy.max_attempts = n.min(u32::MAX as u64) as u32;
            }
            "backoff" => policy.backoff = parse_backoff(value)?,
            "jitter" => {
                policy.jitter = match value.trim() {
                    "none" | "0" => Jitter::None,
                    v => Jitter::Spread(num(v, "jitter")?.min(100) as u8),
                }
            }
            other => return Err(SpecError(format!("unknown key '{other}'"))),
        }
    }
    Ok(policy)
}
