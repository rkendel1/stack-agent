use std::time::Duration;

use crate::policy::RetryPolicy;

pub trait Sleeper {
    fn sleep(&mut self, d: Duration);
}

/// Sleeps the current thread.
pub struct ThreadSleeper;

impl Sleeper for ThreadSleeper {
    fn sleep(&mut self, d: Duration) {
        std::thread::sleep(d);
    }
}

/// Records requested sleeps instead of sleeping.
#[derive(Debug, Default)]
pub struct RecordingSleeper {
    pub slept: Vec<Duration>,
}

impl Sleeper for RecordingSleeper {
    fn sleep(&mut self, d: Duration) {
        self.slept.push(d);
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AttemptError {
    pub retryable: bool,
    pub message: String,
}

impl AttemptError {
    pub fn transient(msg: &str) -> Self {
        AttemptError { retryable: true, message: msg.to_string() }
    }

    pub fn fatal(msg: &str) -> Self {
        AttemptError { retryable: false, message: msg.to_string() }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome<T> {
    Succeeded { value: T, attempts: u32 },
    GaveUp { last_error: AttemptError, attempts: u32 },
    Aborted { error: AttemptError, attempts: u32 },
}

pub fn run_with_retry<T, F>(policy: &RetryPolicy, sleeper: &mut dyn Sleeper, mut op: F) -> Outcome<T>
where
    F: FnMut(u32) -> Result<T, AttemptError>,
{
    let mut attempt = 1;
    loop {
        match op(attempt) {
            Ok(value) => return Outcome::Succeeded { value, attempts: attempt },
            Err(e) if !e.retryable => return Outcome::Aborted { error: e, attempts: attempt },
            Err(e) => match policy.delay_before(attempt) {
                Some(d) => {
                    sleeper.sleep(d);
                    attempt += 1;
                }
                None => return Outcome::GaveUp { last_error: e, attempts: attempt },
            },
        }
    }
}
