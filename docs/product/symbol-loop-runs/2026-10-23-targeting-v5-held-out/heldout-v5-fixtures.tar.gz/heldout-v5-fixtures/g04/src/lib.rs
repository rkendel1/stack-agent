//! Retry policies for background jobs: backoff curves, a small textual spec
//! format, and a runner that drives an operation until it succeeds or the
//! policy gives up.

pub mod backoff;
pub mod policy;
pub mod runner;
pub mod spec;

pub use backoff::Backoff;
pub use policy::{Jitter, RetryPolicy};
pub use runner::{run_with_retry, AttemptError, Outcome, RecordingSleeper, Sleeper, ThreadSleeper};
pub use spec::{parse_backoff, parse_policy, SpecError};
