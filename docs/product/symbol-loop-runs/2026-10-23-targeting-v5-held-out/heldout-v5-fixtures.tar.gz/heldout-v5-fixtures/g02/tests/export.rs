use rowexport::{Exporter, ExportError, Record, Value};

fn people() -> Vec<Record> {
    vec![
        Record::new().with("name", "Ada Lovelace").with("age", 36i64).with("active", true),
        Record::new().with("name", "Grace Hopper").with("age", 85i64).with("active", false),
    ]
}

#[test]
fn csv_plain_rows() {
    let out = Exporter::from_format("csv").unwrap().export(&people()).unwrap();
    assert_eq!(out, "name,age,active\nAda Lovelace,36,true\nGrace Hopper,85,false\n");
}

#[test]
fn csv_embedded_quotes_are_doubled() {
    let recs = vec![Record::new().with("id", 7i64).with("note", "she said \"hi\", then left")];
    let out = Exporter::from_format("CSV").unwrap().without_header().export(&recs).unwrap();
    assert_eq!(out, "7,\"she said \"\"hi\"\", then left\"\n");
}

#[test]
fn quoted_csv_header_with_quote_in_column_name() {
    let recs = vec![Record::new().with("size \"in\"", 12i64)];
    let out = Exporter::from_format("csv-quoted").unwrap().export(&recs).unwrap();
    assert_eq!(out, "\"size \"\"in\"\"\"\n\"12\"\n");
}

#[test]
fn tsv_escapes_tabs_and_newlines() {
    let recs = vec![Record::new().with("a", "x\ty").with("b", "line1\nline2")];
    let out = Exporter::from_format("tsv").unwrap().export(&recs).unwrap();
    assert_eq!(out, "a\tb\nx\\ty\tline1\\nline2\n");
}

#[test]
fn logfmt_skips_missing_and_quotes_spaces() {
    let mut recs = people();
    recs.push(Record::new().with("name", "anon"));
    let out = Exporter::from_format("logfmt")
        .unwrap()
        .columns(&["name", "age"])
        .export(&recs)
        .unwrap();
    assert_eq!(out, "name=\"Ada Lovelace\" age=36\nname=\"Grace Hopper\" age=85\nname=anon\n");
}

#[test]
fn unknown_format_is_rejected() {
    match Exporter::from_format("xml") {
        Err(e) => assert_eq!(e, ExportError::UnknownFormat("xml".into())),
        Ok(_) => panic!("xml should not be supported"),
    }
}

#[test]
fn floats_and_missing_values_in_csv() {
    let recs = vec![
        Record::new().with("k", "a").with("v", 2.0f64),
        Record::new().with("k", "b"),
    ];
    let out = Exporter::from_format("csv").unwrap().export(&recs).unwrap();
    assert_eq!(out, "k,v\na,2.0\nb,\n");
    assert_eq!(Value::Missing.raw(), "");
}
