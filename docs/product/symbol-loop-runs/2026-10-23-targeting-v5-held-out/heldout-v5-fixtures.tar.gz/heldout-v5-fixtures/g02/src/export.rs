use std::fmt;

use crate::encode::Encoder;
use crate::registry::encoder_for;
use crate::value::Record;

#[derive(Debug, Clone, PartialEq)]
pub enum ExportError {
    UnknownFormat(String),
    NoColumns,
}

impl fmt::Display for ExportError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ExportError::UnknownFormat(name) => write!(f, "unknown export format '{name}'"),
            ExportError::NoColumns => f.write_str("no columns to export"),
        }
    }
}

impl std::error::Error for ExportError {}

pub struct Exporter {
    encoder: Box<dyn Encoder>,
    columns: Vec<String>,
    with_header: bool,
}

impl Exporter {
    pub fn from_format(format: &str) -> Result<Exporter, ExportError> {
        let encoder = encoder_for(format).ok_or_else(|| ExportError::UnknownFormat(format.to_string()))?;
        Ok(Exporter { encoder, columns: Vec::new(), with_header: true })
    }

    pub fn columns(mut self, cols: &[&str]) -> Self {
        self.columns = cols.iter().map(|c| c.to_string()).collect();
        self
    }

    pub fn without_header(mut self) -> Self {
        self.with_header = false;
        self
    }

    pub fn format_name(&self) -> &'static str {
        self.encoder.name()
    }

    /// Uses the union of keys over all records, in first-seen order.
    fn resolve_columns(&self, records: &[Record]) -> Vec<String> {
        if !self.columns.is_empty() {
            return self.columns.clone();
        }
        let mut cols: Vec<String> = Vec::new();
        for r in records {
            for k in r.keys() {
                if !cols.iter().any(|c| c == k) {
                    cols.push(k.to_string());
                }
            }
        }
        cols
    }

    pub fn export(&self, records: &[Record]) -> Result<String, ExportError> {
        let cols = self.resolve_columns(records);
        if cols.is_empty() {
            return Err(ExportError::NoColumns);
        }
        let mut out = String::new();
        if self.with_header {
            if let Some(h) = self.encoder.header(&cols) {
                out.push_str(&h);
                out.push('\n');
            }
        }
        for r in records {
            out.push_str(&self.encoder.encode_record(r, &cols));
            out.push('\n');
        }
        Ok(out)
    }
}
