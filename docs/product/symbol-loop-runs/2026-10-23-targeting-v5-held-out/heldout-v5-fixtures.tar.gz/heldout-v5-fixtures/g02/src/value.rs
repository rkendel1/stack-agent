use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Text(String),
    Int(i64),
    Float(f64),
    Bool(bool),
    Missing,
}

impl Value {
    pub fn text(s: &str) -> Value {
        Value::Text(s.to_string())
    }

    pub fn is_missing(&self) -> bool {
        matches!(self, Value::Missing)
    }

    /// Plain textual form without any format-specific escaping.
    pub fn raw(&self) -> String {
        match self {
            Value::Text(s) => s.clone(),
            Value::Int(i) => i.to_string(),
            Value::Float(x) => {
                if x.fract() == 0.0 && x.abs() < 1e15 {
                    format!("{x:.1}")
                } else {
                    x.to_string()
                }
            }
            Value::Bool(b) => b.to_string(),
            Value::Missing => String::new(),
        }
    }
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.raw())
    }
}

impl From<&str> for Value {
    fn from(s: &str) -> Self {
        Value::text(s)
    }
}

impl From<i64> for Value {
    fn from(i: i64) -> Self {
        Value::Int(i)
    }
}

impl From<bool> for Value {
    fn from(b: bool) -> Self {
        Value::Bool(b)
    }
}

impl From<f64> for Value {
    fn from(x: f64) -> Self {
        Value::Float(x)
    }
}

/// A record is an ordered list of named fields.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Record {
    fields: Vec<(String, Value)>,
}

impl Record {
    pub fn new() -> Self {
        Record { fields: Vec::new() }
    }

    pub fn with(mut self, key: &str, value: impl Into<Value>) -> Self {
        self.set(key, value.into());
        self
    }

    pub fn set(&mut self, key: &str, value: Value) {
        if let Some(slot) = self.fields.iter_mut().find(|(k, _)| k == key) {
            slot.1 = value;
        } else {
            self.fields.push((key.to_string(), value));
        }
    }

    pub fn get(&self, key: &str) -> &Value {
        const MISSING: Value = Value::Missing;
        self.fields.iter().find(|(k, _)| k == key).map(|(_, v)| v).unwrap_or(&MISSING)
    }

    pub fn keys(&self) -> impl Iterator<Item = &str> {
        self.fields.iter().map(|(k, _)| k.as_str())
    }
}
