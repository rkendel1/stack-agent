use crate::value::{Record, Value};

/// A line-oriented output format.
pub trait Encoder {
    fn name(&self) -> &'static str;

    fn separator(&self) -> &'static str;

    fn encode_field(&self, value: &Value) -> String;

    fn header(&self, columns: &[String]) -> Option<String> {
        let cells: Vec<String> = columns.iter().map(|c| self.encode_field(&Value::text(c))).collect();
        Some(cells.join(self.separator()))
    }

    fn encode_record(&self, record: &Record, columns: &[String]) -> String {
        let cells: Vec<String> = columns.iter().map(|c| self.encode_field(record.get(c))).collect();
        cells.join(self.separator())
    }
}

/// RFC 4180 style comma separated values.
#[derive(Debug, Default, Clone)]
pub struct CsvEncoder {
    pub quote_all: bool,
}

impl Encoder for CsvEncoder {
    fn name(&self) -> &'static str {
        "csv"
    }

    fn separator(&self) -> &'static str {
        ","
    }

    fn encode_field(&self, value: &Value) -> String {
        let raw = value.raw();
        let needs_quotes = self.quote_all
            || raw.contains(',')
            || raw.contains('"')
            || raw.contains('\n')
            || raw.contains('\r')
            || raw.starts_with(' ')
            || raw.ends_with(' ');
        if needs_quotes {
            format!("\"{}\"", raw)
        } else {
            raw
        }
    }
}

/// Tab separated values; control characters are backslash-escaped.
#[derive(Debug, Default, Clone)]
pub struct TsvEncoder;

impl Encoder for TsvEncoder {
    fn name(&self) -> &'static str {
        "tsv"
    }

    fn separator(&self) -> &'static str {
        "\t"
    }

    fn encode_field(&self, value: &Value) -> String {
        let raw = value.raw();
        let mut out = String::with_capacity(raw.len());
        for ch in raw.chars() {
            match ch {
                '\\' => out.push_str("\\\\"),
                '\t' => out.push_str("\\t"),
                '\n' => out.push_str("\\n"),
                '\r' => out.push_str("\\r"),
                c => out.push(c),
            }
        }
        out
    }
}

/// `key=value` pairs separated by spaces, as used by many log shippers.
#[derive(Debug, Default, Clone)]
pub struct KvEncoder {
    pub skip_missing: bool,
}

impl Encoder for KvEncoder {
    fn name(&self) -> &'static str {
        "kv"
    }

    fn separator(&self) -> &'static str {
        " "
    }

    fn encode_field(&self, value: &Value) -> String {
        let raw = value.raw();
        if raw.is_empty() {
            return "\"\"".to_string();
        }
        if raw.chars().any(|c| c.is_whitespace() || c == '"' || c == '=') {
            let escaped = raw.replace('\\', "\\\\").replace('"', "\\\"");
            format!("\"{escaped}\"")
        } else {
            raw
        }
    }

    fn header(&self, _columns: &[String]) -> Option<String> {
        None
    }

    fn encode_record(&self, record: &Record, columns: &[String]) -> String {
        let mut parts = Vec::new();
        for c in columns {
            let v = record.get(c);
            if self.skip_missing && v.is_missing() {
                continue;
            }
            parts.push(format!("{}={}", c, self.encode_field(v)));
        }
        parts.join(self.separator())
    }
}
