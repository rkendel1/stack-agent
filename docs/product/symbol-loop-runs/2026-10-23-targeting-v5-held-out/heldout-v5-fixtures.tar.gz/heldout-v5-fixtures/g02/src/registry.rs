use crate::encode::{CsvEncoder, Encoder, KvEncoder, TsvEncoder};

pub fn known_formats() -> &'static [&'static str] {
    &["csv", "csv-quoted", "tsv", "kv", "logfmt"]
}

/// Looks up an encoder by format name (case-insensitive).
pub fn encoder_for(format: &str) -> Option<Box<dyn Encoder>> {
    match format.trim().to_ascii_lowercase().as_str() {
        "csv" => Some(Box::new(CsvEncoder::default())),
        "csv-quoted" => Some(Box::new(CsvEncoder { quote_all: true })),
        "tsv" | "tab" => Some(Box::new(TsvEncoder)),
        "kv" => Some(Box::new(KvEncoder { skip_missing: false })),
        "logfmt" => Some(Box::new(KvEncoder { skip_missing: true })),
        _ => None,
    }
}
