use quilltext::{Editor, Motion};

const POEM: &str = "roses are red\nviolets are blue\nsugar is sweet\nand so are you";

#[test]
fn current_line_at_buffer_start() {
    let ed = Editor::open(POEM);
    assert_eq!(ed.current_line().as_deref(), Some("roses are red"));
}

#[test]
fn current_line_in_the_middle_of_a_line() {
    let mut ed = Editor::open(POEM);
    ed.move_to(20);
    assert_eq!(ed.column(), 6);
    assert_eq!(ed.current_line().as_deref(), Some("violets are blue"));
}

#[test]
fn current_line_after_search_on_last_line() {
    let mut ed = Editor::open(POEM);
    assert!(ed.find_next("you"));
    assert_eq!(ed.current_line().as_deref(), Some("and so are you"));
}

#[test]
fn typing_updates_the_line_under_the_cursor() {
    let mut ed = Editor::open("alpha\nbeta\n");
    ed.move_to(7);
    ed.motion(Motion::LineEnd);
    ed.type_text("max");
    assert_eq!(ed.current_line().as_deref(), Some("betamax"));
    assert!(ed.view.doc.is_dirty());
}

#[test]
fn motions_and_columns() {
    let mut ed = Editor::open("héllo wörld\nnext");
    ed.motion(Motion::LineEnd);
    assert_eq!(ed.column(), 11);
    ed.motion(Motion::Left);
    ed.motion(Motion::Left);
    assert_eq!(ed.column(), 9);
    ed.motion(Motion::BufferEnd);
    ed.motion(Motion::LineStart);
    assert_eq!(ed.cursor(), "héllo wörld\n".len());
    ed.backspace();
    assert_eq!(ed.view.doc.text(), "héllo wörldnext");
}

#[test]
fn visible_lines_follow_scrolling() {
    let mut ed = Editor::open("1\n2\n3\n4\n5\n6");
    ed.view.height = 3;
    ed.view.scroll_to(10);
    assert_eq!(ed.view.visible_lines(), vec!["4", "5", "6"]);
    ed.view.show_whitespace = true;
    ed.view.scroll_to(0);
    assert_eq!(ed.view.visible_lines()[0], "1");
}

#[test]
fn crlf_lines_are_presented_without_carriage_return() {
    let mut ed = Editor::open("one\r\ntwo\r\nthree");
    ed.move_to(7);
    assert_eq!(ed.current_line().as_deref(), Some("two"));
}
