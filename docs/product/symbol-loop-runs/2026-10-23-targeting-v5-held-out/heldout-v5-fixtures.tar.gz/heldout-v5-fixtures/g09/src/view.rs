use crate::document::Document;

/// A window onto a document: tracks scrolling and how lines are presented.
#[derive(Debug, Clone)]
pub struct View {
    pub doc: Document,
    pub top_line: usize,
    pub height: usize,
    pub show_whitespace: bool,
}

impl View {
    pub fn new(doc: Document, height: usize) -> View {
        View { doc, top_line: 0, height: height.max(1), show_whitespace: false }
    }

    fn present(&self, raw: &str) -> String {
        let raw = raw.strip_suffix('\r').unwrap_or(raw);
        if self.show_whitespace {
            raw.replace(' ', "·").replace('\t', "→")
        } else {
            raw.to_string()
        }
    }

    /// The presented text of the line containing `offset`.
    pub fn line_containing(&self, offset: usize) -> Option<String> {
        self.doc.line_at_offset(offset).map(|raw| self.present(raw))
    }

    /// Lines currently on screen.
    pub fn visible_lines(&self) -> Vec<String> {
        (self.top_line..self.top_line + self.height)
            .filter_map(|i| self.doc.line_text(i))
            .map(|l| self.present(l))
            .collect()
    }

    pub fn scroll_to(&mut self, line: usize) {
        let max_top = self.doc.line_count().saturating_sub(self.height);
        self.top_line = line.min(max_top);
    }
}
