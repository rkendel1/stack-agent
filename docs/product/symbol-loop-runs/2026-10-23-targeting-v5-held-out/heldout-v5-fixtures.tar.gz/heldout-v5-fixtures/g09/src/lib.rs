//! Core buffer model of a small terminal text editor.

pub mod document;
pub mod editor;
pub mod index;
pub mod view;

pub use document::Document;
pub use editor::{Editor, Motion};
pub use index::LineIndex;
pub use view::View;
