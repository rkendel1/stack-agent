use crate::document::Document;
use crate::view::View;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Motion {
    Left,
    Right,
    LineStart,
    LineEnd,
    BufferStart,
    BufferEnd,
}

pub struct Editor {
    pub view: View,
    cursor: usize,
}

impl Editor {
    pub fn open(text: &str) -> Editor {
        Editor { view: View::new(Document::new(text), 24), cursor: 0 }
    }

    pub fn cursor(&self) -> usize {
        self.cursor
    }

    fn text(&self) -> &str {
        self.view.doc.text()
    }

    pub fn move_to(&mut self, offset: usize) {
        let mut o = offset.min(self.text().len());
        while !self.text().is_char_boundary(o) {
            o -= 1;
        }
        self.cursor = o;
    }

    pub fn motion(&mut self, m: Motion) {
        let text = self.text();
        let c = self.cursor;
        let target = match m {
            Motion::Left => text[..c].char_indices().next_back().map(|(i, _)| i).unwrap_or(0),
            Motion::Right => text[c..].chars().next().map(|ch| c + ch.len_utf8()).unwrap_or(c),
            Motion::LineStart => text[..c].rfind('\n').map(|i| i + 1).unwrap_or(0),
            Motion::LineEnd => text[c..].find('\n').map(|i| c + i).unwrap_or(text.len()),
            Motion::BufferStart => 0,
            Motion::BufferEnd => text.len(),
        };
        self.cursor = target;
    }

    /// Finds the next occurrence of `needle` after the cursor and moves to it.
    pub fn find_next(&mut self, needle: &str) -> bool {
        let from = (self.cursor + 1).min(self.text().len());
        match self.text()[from..].find(needle) {
            Some(i) => {
                self.cursor = from + i;
                true
            }
            None => false,
        }
    }

    pub fn type_text(&mut self, s: &str) {
        let at = self.cursor;
        self.view.doc.insert(at, s);
        self.cursor = at + s.len();
    }

    pub fn backspace(&mut self) {
        let end = self.cursor;
        self.motion(Motion::Left);
        let start = self.cursor;
        self.view.doc.delete(start, end);
    }

    /// The line the cursor is on, as displayed.
    pub fn current_line(&self) -> Option<String> {
        self.view.line_containing(self.cursor)
    }

    pub fn column(&self) -> usize {
        self.view.doc.column_of(self.cursor)
    }
}
