use crate::index::LineIndex;

#[derive(Debug, Clone)]
pub struct Document {
    text: String,
    index: LineIndex,
    dirty: bool,
}

impl Document {
    pub fn new(text: &str) -> Document {
        Document { text: text.to_string(), index: LineIndex::build(text), dirty: false }
    }

    pub fn text(&self) -> &str {
        &self.text
    }

    pub fn len(&self) -> usize {
        self.text.len()
    }

    pub fn is_empty(&self) -> bool {
        self.text.is_empty()
    }

    pub fn is_dirty(&self) -> bool {
        self.dirty
    }

    pub fn line_count(&self) -> usize {
        self.index.line_count()
    }

    /// Text of the line at zero-based index `line`, without its newline.
    pub fn line_text(&self, line: usize) -> Option<&str> {
        let start = self.index.line_start(line)?;
        let end = self.index.line_end(line)?;
        self.text.get(start..end)
    }

    /// Text of the line that contains byte `offset`.
    pub fn line_at_offset(&self, offset: usize) -> Option<&str> {
        if offset > self.text.len() {
            return None;
        }
        let line = self.index.line_of(offset);
        self.line_text(line)
    }

    /// Column (in characters) of `offset` within its line.
    pub fn column_of(&self, offset: usize) -> usize {
        let offset = offset.min(self.text.len());
        let line_start = self.text[..offset].rfind('\n').map(|i| i + 1).unwrap_or(0);
        self.text[line_start..offset].chars().count()
    }

    pub fn insert(&mut self, offset: usize, s: &str) {
        let offset = offset.min(self.text.len());
        self.text.insert_str(offset, s);
        self.index = LineIndex::build(&self.text);
        self.dirty = true;
    }

    pub fn delete(&mut self, start: usize, end: usize) {
        let end = end.min(self.text.len());
        if start >= end {
            return;
        }
        self.text.replace_range(start..end, "");
        self.index = LineIndex::build(&self.text);
        self.dirty = true;
    }
}
