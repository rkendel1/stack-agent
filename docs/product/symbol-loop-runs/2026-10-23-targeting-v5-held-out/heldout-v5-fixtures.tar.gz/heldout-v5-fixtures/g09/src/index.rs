/// Byte offsets at which each line of a text starts.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LineIndex {
    starts: Vec<usize>,
    len: usize,
}

impl LineIndex {
    pub fn build(text: &str) -> LineIndex {
        let mut starts = vec![0];
        for (i, b) in text.bytes().enumerate() {
            if b == b'\n' {
                starts.push(i + 1);
            }
        }
        LineIndex { starts, len: text.len() }
    }

    pub fn line_count(&self) -> usize {
        self.starts.len()
    }

    pub fn line_start(&self, line: usize) -> Option<usize> {
        self.starts.get(line).copied()
    }

    /// End of `line` (exclusive), not counting its newline.
    pub fn line_end(&self, line: usize) -> Option<usize> {
        let start = self.line_start(line)?;
        Some(match self.starts.get(line + 1) {
            Some(next) => (next - 1).max(start),
            None => self.len,
        })
    }

    /// Line number of the line containing `offset`.
    pub fn line_of(&self, offset: usize) -> usize {
        match self.starts.binary_search(&offset) {
            Ok(i) => i + 1,
            Err(i) => i,
        }
    }
}
