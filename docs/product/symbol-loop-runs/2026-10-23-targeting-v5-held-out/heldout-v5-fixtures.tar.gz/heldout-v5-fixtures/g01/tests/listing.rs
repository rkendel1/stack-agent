use shelfwise::{Book, Catalog, Genre, Library, Query, SortKey};

fn sample_library(per_page: usize) -> Library {
    let mut c = Catalog::new();
    let books = [
        ("978-0", "Dune", "Frank Herbert", 1965, Genre::Fiction),
        ("978-1", "Cosmos", "Carl Sagan", 1980, Genre::Science),
        ("978-2", "The Histories", "Herodotus", 1890, Genre::History),
        ("978-3", "Leaves of Grass", "Walt Whitman", 1855, Genre::Poetry),
        ("978-4", "Emma", "Jane Austen", 1815, Genre::Fiction),
        ("978-5", "Matilda", "Roald Dahl", 1988, Genre::Children),
        ("978-6", "Kindred", "Octavia Butler", 1979, Genre::Fiction),
        ("978-7", "The Gene", "Siddhartha Mukherjee", 2016, Genre::Science),
    ];
    for (isbn, t, a, y, g) in books {
        c.add(Book::new(isbn, t, a, y, g).with_copies(2)).unwrap();
    }
    Library::new(c).with_page_size(per_page)
}

#[test]
fn first_page_is_full() {
    let lib = sample_library(3);
    let l = lib.list_page(&Query::all(), 1);
    assert_eq!(l.rows.len(), 3);
    assert_eq!(l.total_pages, 3);
    assert!(l.rows[0].starts_with("Dune - Frank Herbert"));
}

#[test]
fn last_page_is_partial() {
    let lib = sample_library(3);
    let l = lib.list_page(&Query::all(), 3);
    assert_eq!(l.rows.len(), 2);
    assert_eq!(l.footer, "page 3 of 3 - 8 books");
}

#[test]
fn filtered_listing_fits_one_short_page() {
    let lib = sample_library(5);
    let q = Query::all().genre(Genre::Fiction).sorted_by(SortKey::Title);
    let l = lib.list_page(&q, 1);
    let titles: Vec<&str> = l.rows.iter().map(|r| r.split(" - ").next().unwrap()).collect();
    assert_eq!(titles, vec!["Dune", "Emma", "Kindred"]);
}

#[test]
fn page_past_the_end_is_empty() {
    let lib = sample_library(4);
    let l = lib.list_page(&Query::all(), 9);
    assert!(l.rows.is_empty());
    assert_eq!(l.total_pages, 2);
}

#[test]
fn exact_multiple_has_no_partial_page() {
    let lib = sample_library(4);
    assert_eq!(lib.page_count(&Query::all()), 2);
    let l = lib.list_page(&Query::all(), 2);
    assert_eq!(l.rows.len(), 4);
}

#[test]
fn checked_out_books_drop_from_available_query() {
    let mut lib = sample_library(10);
    lib.checkout("978-5").unwrap();
    lib.checkout("978-5").unwrap();
    assert!(lib.checkout("978-5").is_err());
    let l = lib.list_page(&Query::all().available().genre(Genre::Children), 1);
    assert_eq!(l.footer, "no matching books");
    lib.return_copy("978-5").unwrap();
    let l = lib.list_page(&Query::all().available().genre(Genre::Children), 1);
    assert_eq!(l.rows, vec!["Matilda - Roald Dahl (1988) [Children] 1 avail".to_string()]);
}

#[test]
fn newest_science_on_short_second_page() {
    let lib = sample_library(1);
    let q = Query::all().text("the").after(1900).sorted_by(SortKey::YearNewest);
    let l = lib.list_page(&q, 1);
    assert_eq!(l.total_items, 1);
    assert!(l.rows[0].starts_with("The Gene"));
}
