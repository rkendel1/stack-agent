use crate::model::{Book, Catalog};
use crate::pages::{paginate, PageRequest};
use crate::query::Query;

/// A rendered page of the catalog, ready to print or serialise.
#[derive(Debug, Clone, PartialEq)]
pub struct Listing {
    pub rows: Vec<String>,
    pub page: usize,
    pub total_pages: usize,
    pub total_items: usize,
    pub footer: String,
}

pub fn format_row(book: &Book) -> String {
    let avail = match book.available() {
        0 => "out".to_string(),
        n => format!("{n} avail"),
    };
    format!("{} - {} ({}) [{}] {}", book.title, book.author, book.year, book.genre, avail)
}

fn footer(page: usize, total_pages: usize, total_items: usize) -> String {
    if total_items == 0 {
        return "no matching books".to_string();
    }
    let noun = if total_items == 1 { "book" } else { "books" };
    format!("page {page} of {total_pages} - {total_items} {noun}")
}

pub fn render_listing(catalog: &Catalog, query: &Query, req: &PageRequest) -> Listing {
    let hits = query.apply(catalog);
    let page = paginate(&hits, req);
    let rows = page.items.iter().map(|b| format_row(b)).collect();
    Listing {
        rows,
        page: page.number,
        total_pages: page.total_pages,
        total_items: page.total_items,
        footer: footer(page.number, page.total_pages, page.total_items),
    }
}
