use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Genre {
    Fiction,
    History,
    Science,
    Poetry,
    Children,
}

impl Genre {
    pub fn parse(s: &str) -> Option<Genre> {
        match s.trim().to_ascii_lowercase().as_str() {
            "fiction" => Some(Genre::Fiction),
            "history" => Some(Genre::History),
            "science" => Some(Genre::Science),
            "poetry" => Some(Genre::Poetry),
            "children" | "kids" => Some(Genre::Children),
            _ => None,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            Genre::Fiction => "Fiction",
            Genre::History => "History",
            Genre::Science => "Science",
            Genre::Poetry => "Poetry",
            Genre::Children => "Children",
        }
    }
}

impl fmt::Display for Genre {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.label())
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Book {
    pub isbn: String,
    pub title: String,
    pub author: String,
    pub year: u16,
    pub genre: Genre,
    pub copies: u32,
    pub copies_out: u32,
}

impl Book {
    pub fn new(isbn: &str, title: &str, author: &str, year: u16, genre: Genre) -> Self {
        Book {
            isbn: isbn.to_string(),
            title: title.to_string(),
            author: author.to_string(),
            year,
            genre,
            copies: 1,
            copies_out: 0,
        }
    }

    pub fn with_copies(mut self, copies: u32) -> Self {
        self.copies = copies;
        self
    }

    pub fn available(&self) -> u32 {
        self.copies.saturating_sub(self.copies_out)
    }

    /// Author surname, used for shelf ordering.
    pub fn surname(&self) -> &str {
        self.author.rsplit(' ').next().unwrap_or(&self.author)
    }
}

/// In-memory store of books, kept in insertion order.
#[derive(Debug, Default, Clone)]
pub struct Catalog {
    books: Vec<Book>,
}

impl Catalog {
    pub fn new() -> Self {
        Catalog { books: Vec::new() }
    }

    pub fn add(&mut self, book: Book) -> Result<(), String> {
        if self.books.iter().any(|b| b.isbn == book.isbn) {
            return Err(format!("duplicate isbn {}", book.isbn));
        }
        self.books.push(book);
        Ok(())
    }

    pub fn len(&self) -> usize {
        self.books.len()
    }

    pub fn is_empty(&self) -> bool {
        self.books.is_empty()
    }

    pub fn books(&self) -> &[Book] {
        &self.books
    }

    pub fn find(&self, isbn: &str) -> Option<&Book> {
        self.books.iter().find(|b| b.isbn == isbn)
    }

    pub fn find_mut(&mut self, isbn: &str) -> Option<&mut Book> {
        self.books.iter_mut().find(|b| b.isbn == isbn)
    }

    pub fn remove(&mut self, isbn: &str) -> Option<Book> {
        let idx = self.books.iter().position(|b| b.isbn == isbn)?;
        Some(self.books.remove(idx))
    }
}
