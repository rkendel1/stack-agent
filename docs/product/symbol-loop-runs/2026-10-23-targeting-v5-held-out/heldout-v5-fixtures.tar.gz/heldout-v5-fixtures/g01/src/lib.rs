//! A small catalog service for a lending library: books are stored in a
//! [`Catalog`], filtered with a [`Query`], and listed one page at a time.

pub mod model;
pub mod pages;
pub mod query;
pub mod render;

pub use model::{Book, Catalog, Genre};
pub use pages::{Page, PageRequest};
pub use query::{Query, SortKey};
pub use render::Listing;

/// Front door used by the HTTP layer and the CLI.
pub struct Library {
    catalog: Catalog,
    per_page: usize,
}

impl Library {
    pub fn new(catalog: Catalog) -> Self {
        Library { catalog, per_page: 10 }
    }

    pub fn with_page_size(mut self, per_page: usize) -> Self {
        self.per_page = per_page.max(1);
        self
    }

    pub fn catalog(&self) -> &Catalog {
        &self.catalog
    }

    pub fn catalog_mut(&mut self) -> &mut Catalog {
        &mut self.catalog
    }

    /// Lists one page (1-based) of the books that match `query`.
    pub fn list_page(&self, query: &Query, page: usize) -> Listing {
        let req = PageRequest::new(page, self.per_page);
        render::render_listing(&self.catalog, query, &req)
    }

    /// Number of pages a query would produce with the current page size.
    pub fn page_count(&self, query: &Query) -> usize {
        let matched = query.apply(&self.catalog).len();
        pages::page_count(matched, self.per_page)
    }

    pub fn checkout(&mut self, isbn: &str) -> Result<(), String> {
        let book = self
            .catalog
            .find_mut(isbn)
            .ok_or_else(|| format!("unknown isbn {isbn}"))?;
        if book.copies_out >= book.copies {
            return Err(format!("no copies of {} available", book.title));
        }
        book.copies_out += 1;
        Ok(())
    }

    pub fn return_copy(&mut self, isbn: &str) -> Result<(), String> {
        let book = self
            .catalog
            .find_mut(isbn)
            .ok_or_else(|| format!("unknown isbn {isbn}"))?;
        if book.copies_out == 0 {
            return Err(format!("{} has no copies checked out", book.title));
        }
        book.copies_out -= 1;
        Ok(())
    }
}
