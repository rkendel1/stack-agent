/// A request for one page of results. Page numbers start at 1.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PageRequest {
    pub page: usize,
    pub per_page: usize,
}

impl PageRequest {
    pub fn new(page: usize, per_page: usize) -> Self {
        PageRequest { page: page.max(1), per_page: per_page.max(1) }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Page<T> {
    pub items: Vec<T>,
    pub number: usize,
    pub total_pages: usize,
    pub total_items: usize,
}

impl<T> Page<T> {
    pub fn has_next(&self) -> bool {
        self.number < self.total_pages
    }

    pub fn has_prev(&self) -> bool {
        self.number > 1 && self.total_pages > 0
    }
}

pub fn page_count(total: usize, per_page: usize) -> usize {
    let per = per_page.max(1);
    (total + per - 1) / per
}

/// Index range `[start, end)` of the items that belong on the requested page.
pub fn page_bounds(total: usize, req: &PageRequest) -> (usize, usize) {
    let per = req.per_page.max(1);
    let start = (req.page - 1).saturating_mul(per);
    if start >= total {
        return (total, total);
    }
    let end = start + per;
    (start, end)
}

pub fn paginate<T: Clone>(items: &[T], req: &PageRequest) -> Page<T> {
    let (start, end) = page_bounds(items.len(), req);
    Page {
        items: items[start..end].to_vec(),
        number: req.page,
        total_pages: page_count(items.len(), req.per_page),
        total_items: items.len(),
    }
}
