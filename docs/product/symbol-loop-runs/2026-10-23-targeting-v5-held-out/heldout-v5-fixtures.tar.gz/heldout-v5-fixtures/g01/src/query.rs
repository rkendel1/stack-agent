use crate::model::{Book, Catalog, Genre};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SortKey {
    Title,
    Author,
    YearNewest,
    Inserted,
}

/// A filter plus an ordering over the catalog.
#[derive(Debug, Clone)]
pub struct Query {
    pub genre: Option<Genre>,
    pub text: Option<String>,
    pub available_only: bool,
    pub published_after: Option<u16>,
    pub sort: SortKey,
}

impl Default for Query {
    fn default() -> Self {
        Query {
            genre: None,
            text: None,
            available_only: false,
            published_after: None,
            sort: SortKey::Inserted,
        }
    }
}

impl Query {
    pub fn all() -> Self {
        Query::default()
    }

    pub fn genre(mut self, genre: Genre) -> Self {
        self.genre = Some(genre);
        self
    }

    pub fn text(mut self, text: &str) -> Self {
        self.text = Some(text.to_lowercase());
        self
    }

    pub fn available(mut self) -> Self {
        self.available_only = true;
        self
    }

    pub fn after(mut self, year: u16) -> Self {
        self.published_after = Some(year);
        self
    }

    pub fn sorted_by(mut self, key: SortKey) -> Self {
        self.sort = key;
        self
    }

    pub fn matches(&self, book: &Book) -> bool {
        if let Some(g) = self.genre {
            if book.genre != g {
                return false;
            }
        }
        if self.available_only && book.available() == 0 {
            return false;
        }
        if let Some(y) = self.published_after {
            if book.year <= y {
                return false;
            }
        }
        if let Some(t) = &self.text {
            let hay = format!("{} {}", book.title, book.author).to_lowercase();
            if !hay.contains(t.as_str()) {
                return false;
            }
        }
        true
    }

    /// Returns the matching books in the requested order.
    pub fn apply<'a>(&self, catalog: &'a Catalog) -> Vec<&'a Book> {
        let mut hits: Vec<&Book> = catalog.books().iter().filter(|b| self.matches(b)).collect();
        match self.sort {
            SortKey::Title => hits.sort_by(|a, b| a.title.cmp(&b.title)),
            SortKey::Author => {
                hits.sort_by(|a, b| a.surname().cmp(b.surname()).then(a.title.cmp(&b.title)))
            }
            SortKey::YearNewest => hits.sort_by(|a, b| b.year.cmp(&a.year)),
            SortKey::Inserted => {}
        }
        hits
    }
}
