use crate::inventory::Inventory;

fn header() -> String {
    format!("{:<10} {:<20} {:>5}", "SKU", "Item", "Qty")
}

/// Every line, in inventory order.
pub fn full_report(inv: &Inventory) -> String {
    let mut out = header();
    out.push('\n');
    for line in inv.lines() {
        out.push_str(&line.to_string());
        out.push('\n');
    }
    out
}

/// Only the lines that need reordering, most urgent (largest shortfall) first.
pub fn low_stock_report(inv: &Inventory) -> String {
    let mut low: Vec<_> = inv.lines().iter().filter(|l| l.needs_reorder()).collect();
    low.sort_by(|a, b| b.shortfall().cmp(&a.shortfall()).then_with(|| a.sku.as_str().cmp(b.sku.as_str())));
    if low.is_empty() {
        return "nothing to reorder\n".to_string();
    }
    let mut out = header();
    out.push('\n');
    for line in low {
        out.push_str(&format!("{line}\n"));
    }
    out
}
