use std::collections::HashMap;
use std::fmt;

use crate::sku::Sku;
use crate::stock::StockLine;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StockError {
    UnknownSku(String),
    Insufficient { sku: String, wanted: u32, on_hand: u32 },
    InvalidSku(String),
}

impl fmt::Display for StockError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            StockError::UnknownSku(s) => write!(f, "unknown sku {s}"),
            StockError::Insufficient { sku, wanted, on_hand } => {
                write!(f, "cannot ship {wanted} of {sku}: only {on_hand} on hand")
            }
            StockError::InvalidSku(s) => write!(f, "invalid sku '{s}'"),
        }
    }
}

#[derive(Debug, Default)]
pub struct Inventory {
    lines: Vec<StockLine>,
    index: HashMap<Sku, usize>,
}

impl Inventory {
    pub fn new() -> Self {
        Inventory::default()
    }

    pub fn add_line(&mut self, line: StockLine) -> Result<(), StockError> {
        if !line.sku.is_valid() {
            return Err(StockError::InvalidSku(line.sku.to_string()));
        }
        if let Some(&i) = self.index.get(&line.sku) {
            self.lines[i] = line;
        } else {
            self.index.insert(line.sku.clone(), self.lines.len());
            self.lines.push(line);
        }
        Ok(())
    }

    pub fn lines(&self) -> &[StockLine] {
        &self.lines
    }

    pub fn has(&self, sku: &Sku) -> bool {
        self.lines.iter().any(|l| l.sku == *sku)
    }

    pub fn get(&self, sku: &Sku) -> Option<&StockLine> {
        self.index.get(sku).map(|&i| &self.lines[i])
    }

    pub fn on_hand(&self, sku: &str) -> u32 {
        self.get(&Sku::new(sku)).map(|l| l.on_hand).unwrap_or(0)
    }

    pub fn receive(&mut self, sku: &str, qty: u32) -> Result<u32, StockError> {
        let key = Sku::new(sku);
        let i = *self.index.get(&key).ok_or_else(|| StockError::UnknownSku(sku.to_string()))?;
        let line = &mut self.lines[i];
        line.on_hand = line.on_hand.saturating_add(qty);
        Ok(line.on_hand)
    }

    pub fn ship(&mut self, sku: &str, qty: u32) -> Result<u32, StockError> {
        let key = Sku::new(sku);
        let i = *self.index.get(&key).ok_or_else(|| StockError::UnknownSku(sku.to_string()))?;
        let line = &mut self.lines[i];
        if line.on_hand < qty {
            return Err(StockError::Insufficient { sku: line.sku.to_string(), wanted: qty, on_hand: line.on_hand });
        }
        line.on_hand -= qty;
        Ok(line.on_hand)
    }

    pub fn total_units(&self) -> u64 {
        self.lines.iter().map(|l| l.on_hand as u64).sum()
    }
}
