use crate::inventory::Inventory;
use crate::stock::StockLine;

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ImportSummary {
    pub added: usize,
    pub skipped: Vec<(usize, String)>,
}

/// Imports `sku,name,on_hand,reorder_at` rows. A header row is allowed.
pub fn import_csv(inv: &mut Inventory, text: &str) -> ImportSummary {
    let mut summary = ImportSummary::default();
    for (i, raw) in text.lines().enumerate() {
        let line_no = i + 1;
        let row = raw.trim();
        if row.is_empty() || (line_no == 1 && row.to_ascii_lowercase().starts_with("sku,")) {
            continue;
        }
        let cols: Vec<&str> = row.split(',').map(str::trim).collect();
        if cols.len() != 4 {
            summary.skipped.push((line_no, format!("expected 4 columns, found {}", cols.len())));
            continue;
        }
        let (Ok(on_hand), Ok(reorder)) = (cols[2].parse::<u32>(), cols[3].parse::<u32>()) else {
            summary.skipped.push((line_no, "quantities must be whole numbers".to_string()));
            continue;
        };
        match inv.add_line(StockLine::new(cols[0], cols[1], on_hand, reorder)) {
            Ok(()) => summary.added += 1,
            Err(e) => summary.skipped.push((line_no, e.to_string())),
        }
    }
    summary
}
