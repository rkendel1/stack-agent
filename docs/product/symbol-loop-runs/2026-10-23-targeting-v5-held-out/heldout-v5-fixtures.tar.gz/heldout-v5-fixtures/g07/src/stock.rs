use std::fmt;

use crate::sku::Sku;

#[derive(Debug, Clone)]
pub struct StockLine {
    pub sku: Sku,
    pub name: String,
    pub on_hand: u32,
    pub reorder_at: u32,
}

impl StockLine {
    pub fn new(sku: &str, name: &str, on_hand: u32, reorder_at: u32) -> Self {
        StockLine { sku: Sku::new(sku), name: name.to_string(), on_hand, reorder_at }
    }

    /// True when the line has reached its reorder point.
    pub fn needs_reorder(&self) -> bool {
        self.on_hand <= self.reorder_at
    }

    pub fn shortfall(&self) -> u32 {
        (self.reorder_at + 1).saturating_sub(self.on_hand)
    }
}

/// `SKU        Name                    qty` with a trailing `*` on lines that
/// have reached their reorder point.
impl fmt::Display for StockLine {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut name = self.name.clone();
        if name.chars().count() > 20 {
            name = name.chars().take(19).collect::<String>() + "~";
        }
        let marker = if self.on_hand < self.reorder_at { " *" } else { "" };
        write!(f, "{:<10} {:<20} {:>5}{}", self.sku, name, self.on_hand, marker)
    }
}
