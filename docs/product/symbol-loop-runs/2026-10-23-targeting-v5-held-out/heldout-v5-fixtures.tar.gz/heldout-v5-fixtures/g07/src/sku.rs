use std::fmt;
use std::hash::{Hash, Hasher};

/// A stock keeping unit code. Codes are compared case-insensitively and
/// surrounding whitespace is not significant, but the original spelling is
/// kept for display.
#[derive(Debug, Clone)]
pub struct Sku(String);

impl Sku {
    pub fn new(code: &str) -> Sku {
        Sku(code.trim().to_string())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }

    fn normalized(&self) -> String {
        self.0.trim().to_ascii_uppercase()
    }

    /// Codes must be 3-16 characters of letters, digits and hyphens.
    pub fn is_valid(&self) -> bool {
        let n = self.0.len();
        (3..=16).contains(&n) && self.0.chars().all(|c| c.is_ascii_alphanumeric() || c == '-')
    }
}

impl PartialEq for Sku {
    fn eq(&self, other: &Sku) -> bool {
        self.0 == other.0
    }
}

impl Eq for Sku {}

impl Hash for Sku {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.normalized().hash(state);
    }
}

impl fmt::Display for Sku {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(&self.0)
    }
}

impl From<&str> for Sku {
    fn from(s: &str) -> Sku {
        Sku::new(s)
    }
}
