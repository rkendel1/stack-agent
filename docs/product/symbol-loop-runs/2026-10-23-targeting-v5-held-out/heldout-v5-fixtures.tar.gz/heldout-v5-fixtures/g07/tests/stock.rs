use stockroom::{full_report, import_csv, low_stock_report, Inventory, Sku, StockError, StockLine};

const CATALOG: &str = "\
sku,name,on_hand,reorder_at
BOLT-M6,Hex bolt M6 x 30,500,100
NUT-M6,Hex nut M6,80,100
WASH-6,Flat washer 6mm,100,100
GLUE-01,Two-part epoxy adhesive 50ml,12,5
";

fn warehouse() -> Inventory {
    let mut inv = Inventory::new();
    let s = import_csv(&mut inv, CATALOG);
    assert_eq!(s.added, 4);
    inv
}

#[test]
fn import_skips_bad_rows() {
    let mut inv = Inventory::new();
    let s = import_csv(&mut inv, "A-1,thing,1,2\nB-2,other,x,2\nC-3,short\n!!,bad,1,1\n");
    assert_eq!(s.added, 1);
    assert_eq!(s.skipped.iter().map(|(n, _)| *n).collect::<Vec<_>>(), vec![2, 3, 4]);
}

#[test]
fn receive_with_lowercase_code_updates_existing_line() {
    let mut inv = warehouse();
    assert_eq!(inv.receive("nut-m6", 40).unwrap(), 120);
    assert_eq!(inv.on_hand("NUT-M6"), 120);
}

#[test]
fn has_matches_codes_in_any_case() {
    let inv = warehouse();
    assert!(inv.has(&Sku::new("BOLT-M6")));
    assert!(inv.has(&Sku::new(" glue-01 ")));
    assert!(!inv.has(&Sku::new("BOLT-M8")));
}

#[test]
fn shipping_more_than_on_hand_fails() {
    let mut inv = warehouse();
    let err = inv.ship("GLUE-01", 20).unwrap_err();
    assert_eq!(err, StockError::Insufficient { sku: "GLUE-01".into(), wanted: 20, on_hand: 12 });
    assert_eq!(inv.ship("GLUE-01", 2).unwrap(), 10);
    assert_eq!(inv.total_units(), 500 + 80 + 100 + 10);
}

#[test]
fn full_report_truncates_long_names() {
    let inv = warehouse();
    let r = full_report(&inv);
    let lines: Vec<&str> = r.lines().collect();
    assert_eq!(lines[0], "SKU        Item                   Qty");
    assert_eq!(lines[1], "BOLT-M6    Hex bolt M6 x 30       500");
    assert_eq!(lines[4], "GLUE-01    Two-part epoxy adhe~    12");
}

#[test]
fn low_stock_report_flags_items_at_reorder_point() {
    let inv = warehouse();
    let r = low_stock_report(&inv);
    assert_eq!(
        r,
        "SKU        Item                   Qty\n\
         NUT-M6     Hex nut M6              80 *\n\
         WASH-6     Flat washer 6mm        100 *\n"
    );
}

#[test]
fn replacing_a_line_keeps_position() {
    let mut inv = warehouse();
    inv.add_line(StockLine::new("WASH-6", "Flat washer 6mm (zinc)", 300, 50)).unwrap();
    assert_eq!(inv.lines().len(), 4);
    assert_eq!(inv.lines()[2].name, "Flat washer 6mm (zinc)");
    assert_eq!(low_stock_report(&inv).lines().count(), 2);
}
