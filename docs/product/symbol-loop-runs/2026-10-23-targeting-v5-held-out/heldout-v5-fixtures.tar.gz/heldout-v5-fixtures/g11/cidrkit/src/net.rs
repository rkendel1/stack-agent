use std::fmt;

use crate::addr::{format_ipv4, parse_ipv4};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CidrError {
    BadAddress(String),
    BadPrefix(String),
    HostBitsSet(String),
}

impl fmt::Display for CidrError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CidrError::BadAddress(s) => write!(f, "bad address '{s}'"),
            CidrError::BadPrefix(s) => write!(f, "bad prefix length '{s}'"),
            CidrError::HostBitsSet(s) => write!(f, "'{s}' has host bits set"),
        }
    }
}

impl std::error::Error for CidrError {}

/// Network mask with the top `prefix` bits set.
pub fn prefix_mask(prefix: u8) -> u32 {
    !0u32 << (32 - prefix as u32)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Cidr {
    base: u32,
    prefix: u8,
}

impl Cidr {
    pub fn new(base: u32, prefix: u8) -> Option<Cidr> {
        if prefix > 32 || base & !prefix_mask(prefix) != 0 {
            return None;
        }
        Some(Cidr { base, prefix })
    }

    /// Parses `a.b.c.d/n`; a bare address is a /32. Host bits must be zero
    /// unless `strict` is false, in which case they are cleared.
    pub fn parse(s: &str, strict: bool) -> Result<Cidr, CidrError> {
        let s = s.trim();
        let (addr, prefix) = match s.split_once('/') {
            Some((a, p)) => {
                let p: u8 = p.parse().map_err(|_| CidrError::BadPrefix(p.to_string()))?;
                if p > 32 {
                    return Err(CidrError::BadPrefix(p.to_string()));
                }
                (a, p)
            }
            None => (s, 32),
        };
        let ip = parse_ipv4(addr).ok_or_else(|| CidrError::BadAddress(addr.to_string()))?;
        let mask = prefix_mask(prefix);
        if strict && ip & !mask != 0 {
            return Err(CidrError::HostBitsSet(s.to_string()));
        }
        Ok(Cidr { base: ip & mask, prefix })
    }

    pub fn prefix(&self) -> u8 {
        self.prefix
    }

    pub fn first(&self) -> u32 {
        self.base
    }

    pub fn last(&self) -> u32 {
        self.base | !prefix_mask(self.prefix)
    }

    pub fn size(&self) -> u64 {
        1u64 << (32 - self.prefix as u32)
    }

    pub fn contains(&self, ip: u32) -> bool {
        ip & prefix_mask(self.prefix) == self.base
    }

    pub fn contains_net(&self, other: &Cidr) -> bool {
        other.prefix >= self.prefix && self.contains(other.base)
    }
}

impl fmt::Display for Cidr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}/{}", format_ipv4(self.base), self.prefix)
    }
}
