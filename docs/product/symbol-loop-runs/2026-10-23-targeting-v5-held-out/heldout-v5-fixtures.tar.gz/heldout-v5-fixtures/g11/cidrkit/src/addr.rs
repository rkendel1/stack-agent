/// Parses dotted-quad notation into a host-order `u32`.
pub fn parse_ipv4(s: &str) -> Option<u32> {
    let mut out: u32 = 0;
    let mut count = 0;
    for part in s.trim().split('.') {
        if part.is_empty() || part.len() > 3 || !part.chars().all(|c| c.is_ascii_digit()) {
            return None;
        }
        if part.len() > 1 && part.starts_with('0') {
            // leading zeros are ambiguous (octal in some parsers)
            return None;
        }
        let octet: u32 = part.parse().ok()?;
        if octet > 255 {
            return None;
        }
        out = (out << 8) | octet;
        count += 1;
    }
    if count == 4 {
        Some(out)
    } else {
        None
    }
}

pub fn format_ipv4(ip: u32) -> String {
    format!("{}.{}.{}.{}", ip >> 24, (ip >> 16) & 0xff, (ip >> 8) & 0xff, ip & 0xff)
}
