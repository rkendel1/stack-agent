//! IPv4 addresses and CIDR blocks.

pub mod addr;
pub mod net;

pub use addr::{format_ipv4, parse_ipv4};
pub use net::{prefix_mask, Cidr, CidrError};
