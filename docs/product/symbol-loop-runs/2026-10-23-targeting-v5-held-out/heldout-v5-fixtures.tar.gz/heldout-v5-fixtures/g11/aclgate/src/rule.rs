use cidrkit::{parse_ipv4, Cidr};

use crate::ports::PortRange;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Allow,
    Deny,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Rule {
    pub action: Action,
    pub source: Cidr,
    pub ports: PortRange,
    pub comment: Option<String>,
}

impl Rule {
    pub fn matches(&self, ip: u32, port: u16) -> bool {
        self.source.contains(ip) && self.ports.contains(port)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Decision {
    pub action: Action,
    /// Index of the matching rule, or `None` when the default applied.
    pub rule: Option<usize>,
}

#[derive(Debug, Clone)]
pub struct Acl {
    pub rules: Vec<Rule>,
    pub default: Action,
}

impl Acl {
    pub fn new(default: Action) -> Acl {
        Acl { rules: Vec::new(), default }
    }

    pub fn push(&mut self, rule: Rule) {
        self.rules.push(rule);
    }

    pub fn decide(&self, ip: u32, port: u16) -> Decision {
        for (i, r) in self.rules.iter().enumerate() {
            if r.matches(ip, port) {
                return Decision { action: r.action, rule: Some(i) };
            }
        }
        Decision { action: self.default, rule: None }
    }

    /// Convenience wrapper taking a dotted-quad address.
    pub fn check(&self, addr: &str, port: u16) -> Option<Action> {
        parse_ipv4(addr).map(|ip| self.decide(ip, port).action)
    }

    /// Rules that can never match because an earlier rule covers them.
    pub fn shadowed(&self) -> Vec<usize> {
        let mut out = Vec::new();
        for (j, later) in self.rules.iter().enumerate() {
            let covered = self.rules[..j].iter().any(|earlier| {
                earlier.source.contains_net(&later.source)
                    && earlier.ports.lo <= later.ports.lo
                    && earlier.ports.hi >= later.ports.hi
            });
            if covered {
                out.push(j);
            }
        }
        out
    }
}
