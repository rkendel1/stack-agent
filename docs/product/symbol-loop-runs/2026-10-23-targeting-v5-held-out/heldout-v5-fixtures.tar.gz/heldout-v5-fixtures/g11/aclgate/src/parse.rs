use std::fmt;

use cidrkit::Cidr;

use crate::ports::PortRange;
use crate::rule::{Acl, Action, Rule};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseError {
    pub line: usize,
    pub message: String,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "acl line {}: {}", self.line, self.message)
    }
}

fn parse_action(s: &str) -> Option<Action> {
    match s {
        "allow" | "permit" => Some(Action::Allow),
        "deny" | "drop" => Some(Action::Deny),
        _ => None,
    }
}

/// Parses an ACL file:
///
/// ```text
/// default deny
/// allow 10.0.0.0/8 port 22      # ops
/// deny  0.0.0.0/0 port 1-1023
/// ```
pub fn parse_acl(text: &str) -> Result<Acl, ParseError> {
    let mut acl = Acl::new(Action::Deny);
    for (i, raw) in text.lines().enumerate() {
        let line_no = i + 1;
        let (body, comment) = match raw.split_once('#') {
            Some((b, c)) => (b, Some(c.trim().to_string()).filter(|c| !c.is_empty())),
            None => (raw, None),
        };
        let words: Vec<&str> = body.split_whitespace().collect();
        let err = |m: String| ParseError { line: line_no, message: m };
        match words.as_slice() {
            [] => continue,
            ["default", a] => {
                acl.default = parse_action(a).ok_or_else(|| err(format!("unknown action '{a}'")))?;
            }
            [a, net, rest @ ..] => {
                let action = parse_action(a).ok_or_else(|| err(format!("unknown action '{a}'")))?;
                let source = Cidr::parse(net, true).map_err(|e| err(e.to_string()))?;
                let ports = match rest {
                    [] => PortRange::ANY,
                    ["port", p] => PortRange::parse(p).ok_or_else(|| err(format!("bad port range '{p}'")))?,
                    _ => return Err(err("expected 'port <range>'".to_string())),
                };
                acl.push(Rule { action, source, ports, comment });
            }
            _ => return Err(err(format!("cannot parse '{}'", body.trim()))),
        }
    }
    Ok(acl)
}
