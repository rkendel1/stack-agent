use aclgate::{parse_acl, Action, PortRange};
use cidrkit::{parse_ipv4, Cidr};

const POLICY: &str = "\
default deny
allow 10.20.0.0/16 port 22        # ops bastion
deny  10.20.99.0/24               # quarantine
allow 10.0.0.0/8 port 8000-8080   # internal apps
allow 192.168.1.10                # build server
";

#[test]
fn cidr_parsing_and_ranges() {
    let c = Cidr::parse("172.16.0.0/12", true).unwrap();
    assert_eq!(c.size(), 1 << 20);
    assert_eq!(c.last(), parse_ipv4("172.31.255.255").unwrap());
    assert!(Cidr::parse("172.16.0.1/12", true).is_err());
    assert_eq!(Cidr::parse("172.16.0.1/12", false).unwrap().to_string(), "172.16.0.0/12");
    assert!(parse_ipv4("10.01.0.1").is_none());
}

#[test]
fn first_match_wins() {
    let acl = parse_acl(POLICY).unwrap();
    assert_eq!(acl.check("10.20.99.7", 22), Some(Action::Allow));
    assert_eq!(acl.check("10.20.99.7", 8001), Some(Action::Deny));
    assert_eq!(acl.check("192.168.1.10", 5432), Some(Action::Allow));
    assert_eq!(acl.check("192.168.1.11", 5432), Some(Action::Deny));
}

#[test]
fn upper_end_of_port_range_is_included() {
    let acl = parse_acl(POLICY).unwrap();
    assert_eq!(acl.check("10.1.2.3", 8000), Some(Action::Allow));
    assert_eq!(acl.check("10.1.2.3", 8080), Some(Action::Allow));
    assert_eq!(acl.check("10.1.2.3", 8081), Some(Action::Deny));
}

#[test]
fn catch_all_network_rule() {
    let acl = parse_acl("default allow\ndeny 0.0.0.0/0 port 25  # no smtp\nallow 10.0.0.0/8\n").unwrap();
    assert_eq!(acl.check("203.0.113.9", 25), Some(Action::Deny));
    assert_eq!(acl.check("203.0.113.9", 443), Some(Action::Allow));
    assert_eq!(acl.shadowed(), Vec::<usize>::new());
}

#[test]
fn whole_internet_block() {
    let any = Cidr::parse("0.0.0.0/0", true).unwrap();
    assert_eq!(any.size(), 1u64 << 32);
    assert!(any.contains(parse_ipv4("8.8.8.8").unwrap()));
    assert_eq!(any.last(), u32::MAX);
}

#[test]
fn single_port_and_any() {
    assert_eq!(PortRange::parse("443"), Some(PortRange::single(443)));
    assert!(PortRange::single(443).contains(443));
    assert!(PortRange::ANY.contains(1));
    assert!(PortRange::parse("90-80").is_none());
    assert_eq!(PortRange::parse("8000-8080").unwrap().to_string(), "8000-8080");
}

#[test]
fn parse_errors_carry_line_numbers() {
    let e = parse_acl("default deny\nallow 10.0.0.1/8\n").unwrap_err();
    assert_eq!(e.line, 2);
    assert!(e.message.contains("host bits"));
    let e = parse_acl("allow 10.0.0.0/8 ports 22\n").unwrap_err();
    assert_eq!(e.line, 1);
}

#[test]
fn shadowed_rules_are_reported() {
    let acl = parse_acl("allow 10.0.0.0/8 port 1-1024\ndeny 10.1.0.0/16 port 22\ndeny 11.0.0.0/8\n").unwrap();
    assert_eq!(acl.shadowed(), vec![1]);
}
