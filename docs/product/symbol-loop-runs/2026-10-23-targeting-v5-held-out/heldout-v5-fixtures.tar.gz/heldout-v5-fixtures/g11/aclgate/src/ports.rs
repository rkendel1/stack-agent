use std::fmt;

/// An inclusive range of TCP ports.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PortRange {
    pub lo: u16,
    pub hi: u16,
}

impl PortRange {
    pub const ANY: PortRange = PortRange { lo: 0, hi: u16::MAX };

    pub fn single(port: u16) -> PortRange {
        PortRange { lo: port, hi: port }
    }

    /// Parses `any`, `443` or `8000-8080`.
    pub fn parse(s: &str) -> Option<PortRange> {
        let s = s.trim();
        if s == "any" || s == "*" {
            return Some(PortRange::ANY);
        }
        match s.split_once('-') {
            Some((a, b)) => {
                let lo: u16 = a.trim().parse().ok()?;
                let hi: u16 = b.trim().parse().ok()?;
                if lo > hi {
                    return None;
                }
                Some(PortRange { lo, hi })
            }
            None => s.parse().ok().map(PortRange::single),
        }
    }

    pub fn contains(&self, port: u16) -> bool {
        port >= self.lo && port < self.hi
    }
}

impl fmt::Display for PortRange {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if *self == PortRange::ANY {
            f.write_str("any")
        } else if self.lo == self.hi {
            write!(f, "{}", self.lo)
        } else {
            write!(f, "{}-{}", self.lo, self.hi)
        }
    }
}
